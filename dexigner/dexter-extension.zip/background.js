// background.js - Dexter Sipariş Entegrasyonu Background Service Worker
// Acts as a proxy between content script and desktop Electron server (bypassing CSP)

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (message.action === 'checkAuth') {
        fetch('http://127.0.0.1:4567/status')
            .then(res => res.json())
            .then(data => {
                sendResponse({
                    success: true,
                    loggedIn: data.loggedIn,
                    email: data.email,
                    expiresAt: data.expiresAt || null,
                    userId: data.userId || null,
                    token: data.token || null
                });
            })
            .catch(err => {
                console.error("Local app /status check failed:", err);
                sendResponse({ success: false, error: err.message });
            });
        return true; // Keep message channel open for async response
    }

    if (message.action === 'fetchSettings') {
        fetch('http://127.0.0.1:4567/settings')
            .then(res => res.json())
            .then(data => {
                sendResponse({ success: true, settings: data });
            })
            .catch(err => {
                console.error("Local app /settings fetch failed:", err);
                sendResponse({ success: false, error: err.message });
            });
        return true; // Keep message channel open for async response
    }

    if (message.action === 'importOrder') {
        fetch('http://127.0.0.1:4567/import', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ text: message.text })
        })
            .then(res => res.json())
            .then(data => {
                sendResponse({ success: !!data.success });
            })
            .catch(err => {
                console.error("Local app /import post failed:", err);
                sendResponse({ success: false, error: err.message });
            });
        return true; // Keep message channel open for async response
    }
});


