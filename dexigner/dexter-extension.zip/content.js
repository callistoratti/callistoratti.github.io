(function() {
    'use strict';

    // Inject CSS for the Toast Notification and Scrape Summary Modal dynamically
    const style = document.createElement('style');
    style.innerHTML = `
        @import url('https://fonts.googleapis.com/css2?family=Outfit:wght@500;600;700;800&family=Plus+Jakarta+Sans:wght@400;500;600;700&display=swap');

        :root {
            --apple-bg-base: #000000;
            --apple-bg-panel: #0b0b0f;
            --apple-bg-input: rgba(255, 255, 255, 0.02);
            --apple-border: rgba(255, 255, 255, 0.05);
            --apple-accent: #0071E3;
            --apple-accent-hover: #147CE5;
            --apple-accent-glow: rgba(0, 113, 227, 0.15);
            --apple-text-primary: #F5F5F7;
            --apple-text-secondary: #86868B;
            --apple-text-muted: #515154;
            --apple-success: #30D158;
            --apple-error: #FF453A;
            --apple-warning: #FF9F0A;
            --apple-shadow-sm: 0 4px 12px rgba(0, 0, 0, 0.5);
            --apple-shadow-md: 0 20px 40px rgba(0, 0, 0, 0.75);
            --apple-shadow-lg: 0 40px 100px rgba(0, 0, 0, 0.85);
        }

        .dexter-toast {
            position: fixed;
            top: 20px;
            right: 20px;
            background: rgba(11, 11, 15, 0.95);
            backdrop-filter: blur(20px);
            -webkit-backdrop-filter: blur(20px);
            border: 1px solid rgba(255, 255, 255, 0.08);
            border-radius: 14px;
            color: #F5F5F7;
            font-family: 'Plus Jakarta Sans', -apple-system, sans-serif;
            font-size: 13px;
            font-weight: 500;
            box-shadow: 0 20px 50px rgba(0,0,0,0.6), 0 0 15px rgba(0, 113, 227, 0.15);
            padding: 16px 22px;
            z-index: 9999999;
            display: flex;
            align-items: center;
            gap: 12px;
            transition: all 0.4s cubic-bezier(0.16, 1, 0.3, 1);
            opacity: 0;
            transform: translateY(-20px) scale(0.95);
            pointer-events: none;
            max-width: 340px;
        }
        .dexter-toast.show {
            opacity: 1;
            transform: translateY(0) scale(1);
        }
        .dexter-toast-icon {
            color: #30D158;
            display: flex;
            align-items: center;
            justify-content: center;
            flex-shrink: 0;
        }
        .dexter-toast-content {
            display: flex;
            flex-direction: column;
            gap: 2px;
        }
        .dexter-toast-title {
            font-family: 'Outfit', sans-serif;
            font-weight: 600;
            color: #FFFFFF;
        }
        .dexter-toast-body {
            font-size: 11px;
            color: #86868B;
            line-height: 1.3;
        }

        .dexter-premium-btn {
            background: #0B0B0F !important;
            color: #FFFFFF !important;
            border: 1px solid rgba(255, 255, 255, 0.1) !important;
            padding: 6px 14px !important;
            border-radius: 8px !important;
            font-size: 11.5px !important;
            font-weight: 500 !important;
            cursor: pointer !important;
            font-family: 'Plus Jakarta Sans', sans-serif !important;
            transition: all 0.25s cubic-bezier(0.16, 1, 0.3, 1) !important;
            display: inline-flex !important;
            align-items: center !important;
            justify-content: center !important;
            gap: 6px !important;
            vertical-align: middle !important;
            outline: none !important;
            text-decoration: none !important;
            margin-left: 10px !important;
            box-shadow: 0 1px 2px rgba(0,0,0,0.2) !important;
        }
        .dexter-premium-btn:hover {
            border-color: #0A84FF !important;
            background: #121217 !important;
            transform: translateY(-1px) !important;
            box-shadow: 0 4px 12px rgba(10, 132, 255, 0.15), 0 0 6px rgba(10, 132, 255, 0.1) !important;
        }
        .dexter-premium-btn:active {
            transform: translateY(0) scale(0.98) !important;
        }

        .dexter-premium-bulk-btn {
            background: #0B0B0F !important;
            color: #FFFFFF !important;
            border: 1px solid rgba(255, 255, 255, 0.12) !important;
            padding: 8px 18px !important;
            border-radius: 10px !important;
            font-size: 12.5px !important;
            font-weight: 600 !important;
            cursor: pointer !important;
            font-family: 'Plus Jakarta Sans', sans-serif !important;
            transition: all 0.25s cubic-bezier(0.16, 1, 0.3, 1) !important;
            display: inline-flex !important;
            align-items: center !important;
            justify-content: center !important;
            gap: 6px !important;
            margin-bottom: 12px !important;
            outline: none !important;
            text-decoration: none !important;
            box-shadow: 0 2px 4px rgba(0,0,0,0.3) !important;
            animation: shopier-subtle-glow 4s infinite ease-in-out !important;
        }
        .dexter-premium-bulk-btn:hover {
            border-color: #0A84FF !important;
            background: #121217 !important;
            transform: translateY(-1.5px) !important;
            box-shadow: 0 8px 20px rgba(10, 132, 255, 0.25), 0 0 10px rgba(10, 132, 255, 0.15) !important;
        }
        .dexter-premium-bulk-btn:active {
            transform: translateY(0) scale(0.98) !important;
        }

        .dexter-shopify-btn-border-svg {
            position: absolute !important;
            top: 0 !important;
            left: 0 !important;
            width: 100% !important;
            height: 100% !important;
            z-index: 0 !important;
            pointer-events: none !important;
            overflow: visible !important;
        }
        .dexter-shopify-btn-border-svg rect {
            x: 1px;
            y: 1px;
            width: calc(100% - 2px);
            height: calc(100% - 2px);
            rx: 8px;
            ry: 8px;
        }
        .dexter-shopify-btn-border-svg .bg-rect {
            stroke: rgba(255, 255, 255, 0.12) !important;
            stroke-width: 1.5px !important;
            fill: none !important;
        }
        .dexter-shopify-btn-border-svg .glow-rect {
            stroke: #0A84FF !important;
            stroke-width: 2px !important;
            fill: none !important;
            stroke-dasharray: 25 75;
            stroke-dashoffset: 100;
            animation: shopify-svg-stroke 2.5s linear infinite !important;
        }
        .dexter-shopify-btn-wrapper:hover .dexter-shopify-btn-border-svg .glow-rect {
            animation-duration: 1.25s !important;
        }
        @keyframes shopify-svg-stroke {
            to {
                stroke-dashoffset: 0;
            }
        }

        .dexter-shopify-btn-wrapper {
            position: relative !important;
            display: inline-flex !important;
            align-items: center !important;
            justify-content: center !important;
            border-radius: 9px !important;
            padding: 1.5px !important;
            background: transparent !important;
            box-sizing: border-box !important;
            animation: shopify-wrapper-glow 3s infinite ease-in-out !important;
        }
        .dexter-shopify-btn-wrapper.floating {
            position: fixed !important;
            bottom: 30px !important;
            right: 30px !important;
            z-index: 9999999 !important;
        }
        .dexter-shopify-btn-wrapper:hover {
            animation: shopify-wrapper-glow-hover 1.5s infinite ease-in-out !important;
        }
        .dexter-shopify-btn-wrapper:active {
            transform: scale(0.98) !important;
        }

        #dexter-floating-scrape-btn {
            position: fixed !important;
            bottom: 24px !important;
            right: 24px !important;
            background: rgba(11, 11, 15, 0.92) !important;
            backdrop-filter: blur(20px) !important;
            -webkit-backdrop-filter: blur(20px) !important;
            border: 1px solid rgba(255, 255, 255, 0.08) !important;
            border-radius: 50px !important;
            color: #FFFFFF !important;
            font-family: 'Outfit', 'Plus Jakarta Sans', -apple-system, sans-serif !important;
            font-size: 13px !important;
            font-weight: 600 !important;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.5), 0 0 15px rgba(0, 113, 227, 0.15) !important;
            padding: 12px 24px !important;
            z-index: 2147483647 !important;
            display: inline-flex !important;
            align-items: center !important;
            justify-content: center !important;
            gap: 8px !important;
            cursor: pointer !important;
            transition: all 0.3s cubic-bezier(0.16, 1, 0.3, 1) !important;
            text-shadow: 0 1px 2px rgba(0,0,0,0.5) !important;
            outline: none !important;
            line-height: 1 !important;
        }
        #dexter-floating-scrape-btn:hover {
            transform: scale(1.05) translateY(-2px) !important;
            border-color: rgba(255, 255, 255, 0.2) !important;
            box-shadow: 0 20px 40px rgba(0, 0, 0, 0.7), 0 0 25px rgba(0, 113, 227, 0.3) !important;
            background: rgba(15, 15, 20, 0.96) !important;
        }
        #dexter-floating-scrape-btn:active {
            transform: scale(0.98) translateY(0) !important;
        }
        #dexter-floating-scrape-btn svg {
            flex-shrink: 0 !important;
            display: block !important;
            width: 14px !important;
            height: 14px !important;
        }

        #dexter-shopify-inline-btn, #dexter-shopify-float-btn {
            position: relative !important;
            z-index: 1 !important;
            background: #0B0B0F !important;
            color: #FFFFFF !important;
            border: none !important;
            padding: 6px 12px !important;
            border-radius: 8px !important;
            font-size: 12px !important;
            font-weight: 600 !important;
            cursor: pointer !important;
            display: inline-flex !important;
            align-items: center !important;
            gap: 6px !important;
            margin: 0 !important;
            font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif !important;
            box-shadow: none !important;
            outline: none !important;
            transition: all 0.2s ease !important;
        }
        #dexter-shopify-float-btn {
            padding: 10px 20px !important;
            font-size: 12.5px !important;
        }
        #dexter-shopify-inline-btn:hover, #dexter-shopify-float-btn:hover {
            background: #121217 !important;
        }

        @keyframes shopify-wrapper-glow {
            0% { box-shadow: 0 1px 2px rgba(0,0,0,0.1), 0 0 10px rgba(10, 132, 255, 0.2); }
            50% { box-shadow: 0 3px 10px rgba(0,0,0,0.12), 0 0 20px rgba(10, 132, 255, 0.55); }
            100% { box-shadow: 0 1px 2px rgba(0,0,0,0.1), 0 0 10px rgba(10, 132, 255, 0.2); }
        }
        @keyframes shopify-wrapper-glow-hover {
            0% { box-shadow: 0 3px 10px rgba(0,0,0,0.12), 0 0 20px rgba(10, 132, 255, 0.55); }
            50% { box-shadow: 0 6px 18px rgba(0,0,0,0.18), 0 0 30px rgba(10, 132, 255, 0.75); }
            100% { box-shadow: 0 3px 10px rgba(0,0,0,0.12), 0 0 20px rgba(10, 132, 255, 0.55); }
        }
        @keyframes shopier-subtle-glow {
            0% { box-shadow: 0 2px 4px rgba(0,0,0,0.3), 0 0 4px rgba(10, 132, 255, 0.05); border-color: rgba(255, 255, 255, 0.12); }
            50% { box-shadow: 0 2px 8px rgba(0,0,0,0.4), 0 0 8px rgba(10, 132, 255, 0.25); border-color: rgba(10, 132, 255, 0.4); }
            100% { box-shadow: 0 2px 4px rgba(0,0,0,0.3), 0 0 4px rgba(10, 132, 255, 0.05); border-color: rgba(255, 255, 255, 0.12); }
        }

                .apple-summary-overlay {
            position: fixed !important;
            top: 0 !important;
            left: 0 !important;
            width: 100vw !important;
            height: 100vh !important;
            background-color: rgba(10, 10, 12, 0.6) !important;
            backdrop-filter: blur(25px) !important;
            -webkit-backdrop-filter: blur(25px) !important;
            z-index: 99999999 !important;
            display: flex !important;
            justify-content: center !important;
            align-items: center !important;
            font-family: 'Plus Jakarta Sans', -apple-system, sans-serif !important;
            opacity: 0 !important;
            transition: opacity 0.3s ease-out !important;
        }
        .apple-summary-overlay.show {
            opacity: 1 !important;
        }
        .apple-summary-panel {
            background: #1C1C1E !important;
            padding: 20px !important;
            border-radius: 20px !important;
            box-shadow: 0 30px 80px rgba(0, 0, 0, 0.6), inset 0 0 0 1px rgba(255, 255, 255, 0.03) !important;
            width: 760px !important;
            max-width: 95% !important;
            height: 600px !important;
            max-height: 90vh !important;
            border: 1px solid rgba(255, 255, 255, 0.08) !important;
            display: flex !important;
            flex-direction: column !important;
            transform: scale(0.96) !important;
            transition: transform 0.35s cubic-bezier(0.16, 1, 0.3, 1), opacity 0.35s ease !important;
            color: #F5F5F7 !important;
            overflow: hidden !important;
            box-sizing: border-box !important;
        }
        .apple-summary-overlay.show .apple-summary-panel {
            transform: scale(1) !important;
        }
        .apple-summary-header {
            display: flex !important;
            justify-content: space-between !important;
            align-items: center !important;
            margin-bottom: 20px !important;
            border-bottom: 1px solid rgba(255, 255, 255, 0.08) !important;
            padding-bottom: 15px !important;
            flex-shrink: 0 !important;
        }
        .apple-summary-header-left {
            display: flex !important;
            align-items: center !important;
        }
        .window-controls {
            display: flex !important;
            gap: 8px !important;
            margin-right: 18px !important;
        }
        .control-dot {
            width: 12px !important;
            height: 12px !important;
            border-radius: 50% !important;
            display: inline-block !important;
            position: relative !important;
        }
        .control-dot.close {
            background-color: #FF5F56 !important;
            border: 1px solid #E0443E !important;
            cursor: pointer !important;
        }
        .control-dot.close:hover {
            background-color: #FF3B30 !important;
        }
        .control-dot.minimize {
            background-color: #FFBD2E !important;
            border: 1px solid #DEA123 !important;
        }
        .control-dot.maximize {
            background-color: #27C93F !important;
            border: 1px solid #1AAB29 !important;
        }
        .header-icon-box {
            width: 38px !important;
            height: 38px !important;
            background: #2C2C2E !important;
            border-radius: 8px !important;
            display: flex !important;
            align-items: center !important;
            justify-content: center !important;
            margin-right: 12px !important;
            color: #F5F5F7 !important;
            border: 1px solid rgba(255, 255, 255, 0.06) !important;
        }
        .header-title-container {
            display: flex !important;
            flex-direction: column !important;
            gap: 2px !important;
            align-items: flex-start !important;
        }
        .apple-summary-title {
            margin: 0 !important;
            color: #FFFFFF !important;
            font-size: 20px !important;
            font-weight: 700 !important;
            letter-spacing: -0.5px !important;
            font-family: 'Outfit', -apple-system, sans-serif !important;
            line-height: 1.2 !important;
        }
        .apple-summary-subtitle {
            font-size: 11.5px !important;
            color: #AEAEB2 !important;
            font-weight: 500 !important;
            font-family: 'Plus Jakarta Sans', sans-serif !important;
        }
        .apple-summary-buttons {
            display: flex !important;
            gap: 12px !important;
        }
        .apple-summary-btn {
            padding: 9px 20px !important;
            border-radius: 30px !important;
            font-size: 13px !important;
            font-weight: 600 !important;
            cursor: pointer !important;
            transition: all 0.3s cubic-bezier(0.16, 1, 0.3, 1) !important;
            display: inline-flex !important;
            align-items: center !important;
            gap: 8px !important;
            font-family: 'Plus Jakarta Sans', sans-serif !important;
            border: 1px solid transparent !important;
            outline: none !important;
            text-decoration: none !important;
        }
        .apple-summary-btn-copy {
            background: #0A84FF !important;
            color: #FFFFFF !important;
            box-shadow: 0 4px 12px rgba(10, 132, 255, 0.25) !important;
        }
        .apple-summary-btn-copy:hover {
            background: #0066CC !important;
            transform: translateY(-2px) scale(1.02) !important;
            box-shadow: 0 8px 18px rgba(10, 132, 255, 0.35) !important;
        }
        .apple-summary-btn-close {
            background: #2C2C2E !important;
            border: 1px solid rgba(255, 255, 255, 0.1) !important;
            color: #F5F5F7 !important;
        }
        .apple-summary-btn-close:hover {
            background: #3A3A3C !important;
            transform: translateY(-2px) scale(1.02) !important;
        }
        .apple-summary-btn:active {
            transform: translateY(0px) scale(0.98) !important;
        }
 
        .dexter-stats-row {
            display: flex !important;
            justify-content: space-between !important;
            gap: 8px !important;
            margin-bottom: 12px !important;
            flex-shrink: 0 !important;
        }
        .stat-item {
            flex: 1 !important;
            background: #2C2C2E !important;
            border: 1px solid rgba(255, 255, 255, 0.08) !important;
            border-radius: 12px !important;
            padding: 8px 12px !important;
            display: flex !important;
            flex-direction: row !important;
            align-items: center !important;
            gap: 8px !important;
            position: relative !important;
            overflow: hidden !important;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.2) !important;
            transition: all 0.3s cubic-bezier(0.16, 1, 0.3, 1) !important;
        }
        .stat-item::after {
            content: "" !important;
            position: absolute !important;
            bottom: 0 !important;
            left: 0 !important;
            width: 100% !important;
            height: 3px !important;
        }
        .stat-item.total-orders::after { background: #0A84FF !important; }
        .stat-item.total-items::after { background: #30D158 !important; }
        .stat-item.note-orders::after { background: #FF9F0A !important; }
        .stat-item.custom-orders::after { background: #BF5AF2 !important; }
        .stat-item.refund-orders::after { background: #FF453A !important; }

        .stat-item:hover {
            transform: translateY(-2px) scale(1.01) !important;
            box-shadow: 0 6px 12px rgba(0, 0, 0, 0.4) !important;
        }
        .stat-icon-wrapper {
            width: 32px !important;
            height: 32px !important;
            border-radius: 8px !important;
            display: flex !important;
            align-items: center !important;
            justify-content: center !important;
            flex-shrink: 0 !important;
        }
        .stat-item.total-orders .stat-icon-wrapper { background: rgba(10, 132, 255, 0.12) !important; color: #0A84FF !important; }
        .stat-item.total-items .stat-icon-wrapper { background: rgba(48, 209, 88, 0.12) !important; color: #30D158 !important; }
        .stat-item.note-orders .stat-icon-wrapper { background: rgba(255, 159, 10, 0.12) !important; color: #FF9F0A !important; }
        .stat-item.custom-orders .stat-icon-wrapper { background: rgba(191, 90, 242, 0.12) !important; color: #BF5AF2 !important; }
        .stat-item.refund-orders .stat-icon-wrapper { background: rgba(255, 69, 58, 0.12) !important; color: #FF453A !important; }
 
        .stat-text-wrapper {
            display: flex !important;
            flex-direction: column !important;
            gap: 1px !important;
            align-items: flex-start !important;
        }
        .stat-val {
            font-size: 16px !important;
            font-weight: 800 !important;
            font-family: 'Outfit', sans-serif !important;
            line-height: 1.1 !important;
        }
        .stat-lbl {
            font-size: 9px !important;
            color: #AEAEB2 !important;
            font-weight: 600 !important;
            text-transform: none !important;
            letter-spacing: normal !important;
        }
        .stat-item.total-orders .stat-val { color: #0A84FF !important; }
        .stat-item.total-items .stat-val { color: #30D158 !important; }
        .stat-item.note-orders .stat-val { color: #FF9F0A !important; }
        .stat-item.custom-orders .stat-val { color: #BF5AF2 !important; }
        .stat-item.refund-orders .stat-val { color: #FF453A !important; }
  
        .apple-summary-content {
            display: flex !important;
            flex: 1 !important;
            min-height: 0 !important;
            gap: 20px !important;
        }
        .apple-summary-left {
            width: 44% !important;
            display: flex !important;
            flex-direction: column !important;
            gap: 16px !important;
            min-height: 0 !important;
        }
        .apple-summary-right {
            width: 56% !important;
            display: flex !important;
            flex-direction: column !important;
            min-height: 0 !important;
        }
 
        .summary-card {
            background: #2C2C2E !important;
            border: 1px solid rgba(255, 255, 255, 0.08) !important;
            border-radius: 20px !important;
            overflow: hidden !important;
            display: flex !important;
            flex-direction: column !important;
            min-height: 0 !important;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.2) !important;
            transition: all 0.3s ease !important;
        }
        .summary-card:hover {
            border-color: rgba(255, 255, 255, 0.15) !important;
        }
        
        .notes-panel {
            flex: 1.4 !important;
            border-left: 4px solid #FF9F0A !important;
        }
        .alerts-panel {
            flex: 1 !important;
            border-left: 4px solid #0A84FF !important;
        }
        
        .summary-card .card-header {
            padding: 12px 18px !important;
            display: flex !important;
            justify-content: space-between !important;
            align-items: center !important;
            font-size: 14px !important;
            font-weight: 700 !important;
            font-family: 'Outfit', sans-serif !important;
            flex-shrink: 0 !important;
            border-bottom: 1px solid rgba(255, 255, 255, 0.08) !important;
        }
        .warning-header {
            background: rgba(255, 159, 10, 0.12) !important;
            color: #FF9F0A !important;
        }
        .accent-header {
            background: rgba(10, 132, 255, 0.12) !important;
            color: #0A84FF !important;
        }
        .summary-card .card-badge {
            font-size: 10px !important;
            font-weight: 700 !important;
            padding: 2px 8px !important;
            border-radius: 20px !important;
            color: #FFFFFF !important;
        }
        .bg-warning { background-color: #FF9F0A !important; color: #FFFFFF !important; }
        .bg-accent { background-color: #0A84FF !important; color: #FFFFFF !important; }
        
        .summary-card .card-body {
            padding: 12px !important;
            overflow-y: auto !important;
            flex-grow: 1 !important;
            display: flex !important;
            flex-direction: column !important;
            gap: 10px !important;
            background: transparent !important;
            min-height: 0 !important;
        }
 
        .note-item {
            background: #1C1C1E !important;
            border: 1px solid rgba(255, 255, 255, 0.06) !important;
            border-radius: 14px !important;
            padding: 12px !important;
            display: flex !important;
            flex-direction: column !important;
            gap: 8px !important;
            transition: all 0.25s cubic-bezier(0.16, 1, 0.3, 1) !important;
        }
        .note-item:hover {
            border-color: rgba(255, 255, 255, 0.12) !important;
            transform: translateX(3px) !important;
        }
        .note-header {
            display: flex !important;
            justify-content: space-between !important;
            align-items: center !important;
        }
        .note-order-id {
            font-size: 12.5px !important;
            font-weight: 700 !important;
            color: #0A84FF !important;
            font-family: 'Outfit', sans-serif !important;
        }
        .note-text-box {
            font-size: 12.5px !important;
            color: #F5F5F7 !important;
            line-height: 1.45 !important;
            background: #1C1C1E !important;
            padding: 10px 12px !important;
            border-radius: 8px !important;
            border-left: 3px solid #FF9F0A !important;
            word-break: break-word !important;
            text-align: left !important;
            box-shadow: none !important;
        }
 
        .alert-item {
            display: flex !important;
            flex-direction: column !important;
            gap: 8px !important;
            background: #1C1C1E !important;
            border: 1px solid rgba(255, 255, 255, 0.06) !important;
            border-radius: 14px !important;
            padding: 12px !important;
            transition: all 0.25s cubic-bezier(0.16, 1, 0.3, 1) !important;
        }
        .alert-item:hover {
            border-color: rgba(255, 255, 255, 0.12) !important;
            transform: translateX(3px) !important;
        }
        .alert-header {
            display: flex !important;
            justify-content: space-between !important;
            align-items: center !important;
        }
        .alert-order-id {
            font-size: 12.5px !important;
            font-weight: 700 !important;
            color: #0A84FF !important;
            font-family: 'Outfit', sans-serif !important;
        }
        .alert-badge-group {
            display: flex !important;
            gap: 6px !important;
        }
        .alert-type-badge {
            font-size: 9.5px !important;
            font-weight: 700 !important;
            padding: 3px 7px !important;
            border-radius: 5px !important;
            text-transform: uppercase !important;
            letter-spacing: 0.3px !important;
            display: inline-flex !important;
            align-items: center !important;
            gap: 4px !important;
        }
        .alert-type-badge.custom {
            color: #BF5AF2 !important;
            background: rgba(191, 90, 242, 0.12) !important;
            border: 1px solid rgba(191, 90, 242, 0.2) !important;
        }
        .alert-type-badge.refund {
            color: #FF453A !important;
            background: rgba(255, 69, 58, 0.12) !important;
            border: 1px solid rgba(255, 69, 58, 0.2) !important;
        }
        .no-items {
            font-size: 12px !important;
            color: #8E8E93 !important;
            text-align: center !important;
            margin-top: 15px !important;
        }
 
        .summary-products-section {
            background: #2C2C2E !important;
            border: 1px solid rgba(255, 255, 255, 0.08) !important;
            border-radius: 20px !important;
            padding: 16px !important;
            display: flex !important;
            flex-direction: column !important;
            min-height: 0 !important;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.2) !important;
            box-sizing: border-box !important;
        }
        .summary-products-section .card-header {
            padding: 0 0 12px 0 !important;
            display: flex !important;
            justify-content: space-between !important;
            align-items: center !important;
            border-bottom: 1px solid rgba(255, 255, 255, 0.08) !important;
            flex-shrink: 0 !important;
        }
        .section-title {
            font-size: 16px !important;
            font-weight: 700 !important;
            color: #FFFFFF !important;
            margin: 0 !important;
            letter-spacing: -0.4px !important;
            font-family: 'Outfit', sans-serif !important;
            display: flex !important;
            align-items: center !important;
            gap: 8px !important;
        }
        .product-list-container {
            flex: 1 !important;
            overflow-y: auto !important;
            display: flex !important;
            flex-direction: column !important;
            gap: 12px !important;
            margin-top: 12px !important;
            padding-right: 4px !important;
            box-sizing: border-box !important;
            min-height: 0 !important;
        }
 
        .model-group-card {
            background: #1C1C1E !important;
            border: 1px solid rgba(255, 255, 255, 0.06) !important;
            border-radius: 14px !important;
            overflow: hidden !important;
            transition: all 0.3s cubic-bezier(0.16, 1, 0.3, 1) !important;
        }
        .model-group-card:hover {
            border-color: rgba(10, 132, 255, 0.4) !important;
        }
        .model-group-header {
            background: #2C2C2E !important;
            padding: 10px 14px !important;
            display: flex !important;
            justify-content: space-between !important;
            align-items: center !important;
            border-bottom: 1px solid rgba(255, 255, 255, 0.06) !important;
        }
        .model-group-title {
            font-size: 13.5px !important;
            font-weight: 700 !important;
            color: #FFFFFF !important;
            font-family: 'Outfit', sans-serif !important;
            display: flex !important;
            align-items: center !important;
            gap: 6px !important;
        }
        .model-group-count-badge {
            font-size: 11px !important;
            font-weight: 700 !important;
            color: #0A84FF !important;
            background: rgba(10, 132, 255, 0.12) !important;
            border: 1px solid rgba(10, 132, 255, 0.2) !important;
            padding: 2px 8px !important;
            border-radius: 20px !important;
            font-family: 'Outfit', sans-serif !important;
        }
        .model-group-body {
            padding: 6px 14px !important;
            display: flex !important;
            flex-direction: column !important;
        }
        .product-item-row {
            display: flex !important;
            align-items: center !important;
            gap: 12px !important;
            padding: 8px 0 !important;
            border-bottom: 1px solid rgba(255, 255, 255, 0.05) !important;
        }
        .product-item-row:last-child {
            border-bottom: none !important;
        }
        .product-item-qty {
            font-size: 12px !important;
            font-weight: 700 !important;
            color: #30D158 !important;
            background: rgba(48, 209, 88, 0.12) !important;
            border: 1px solid rgba(48, 209, 88, 0.2) !important;
            padding: 2px 6px !important;
            border-radius: 6px !important;
            min-width: 28px !important;
            text-align: center !important;
            font-family: 'Outfit', sans-serif !important;
        }
        .product-item-name {
            font-size: 12.5px !important;
            color: #FFFFFF !important;
            flex: 1 !important;
            white-space: nowrap !important;
            overflow: hidden !important;
            text-overflow: ellipsis !important;
            text-align: left !important;
        }
        .product-item-code {
            font-size: 10px !important;
            font-weight: 600 !important;
            color: #AEAEB2 !important;
            background: #2C2C2E !important;
            border: 1px solid rgba(255, 255, 255, 0.06) !important;
            padding: 2px 6px !important;
            border-radius: 5px !important;
            font-family: 'Outfit', sans-serif !important;
        }

        /* Styles for products listed inside left column cards */
        .order-products-list {
            margin: 4px 0 8px 0 !important;
            padding: 6px 10px !important;
            background: #1C1C1E !important;
            border-radius: 8px !important;
            border: 1px solid rgba(255, 255, 255, 0.05) !important;
            display: flex !important;
            flex-direction: column !important;
            gap: 6px !important;
            box-shadow: none !important;
        }
        .order-product-line {
            font-size: 11.5px !important;
            color: #FFFFFF !important;
            display: flex !important;
            align-items: center !important;
            gap: 6px !important;
            text-align: left !important;
        }
        .order-qty-badge {
            color: #0A84FF !important;
            font-weight: 700 !important;
            font-size: 11px !important;
            background: rgba(10, 132, 255, 0.12) !important;
            padding: 1px 4px !important;
            border-radius: 3px !important;
            display: inline-block !important;
            min-width: 18px !important;
            text-align: center !important;
            border: 1px solid rgba(10, 132, 255, 0.2) !important;
        }
        .order-product-name {
            white-space: nowrap !important;
            overflow: hidden !important;
            text-overflow: ellipsis !important;
            flex: 1 !important;
        }
 
        .apple-summary-panel ::-webkit-scrollbar {
            width: 6px !important;
            height: 6px !important;
        }
        .apple-summary-panel ::-webkit-scrollbar-track {
            background: rgba(255, 255, 255, 0.02) !important;
            border-radius: 3px !important;
        }
        .apple-summary-panel ::-webkit-scrollbar-thumb {
            background: rgba(255, 255, 255, 0.15) !important;
            border-radius: 3px !important;
        }
        .apple-summary-panel ::-webkit-scrollbar-thumb:hover {
            background: rgba(255, 255, 255, 0.3) !important;
        }
        
        /* Markdown Document Styles */
        .apple-summary-document-card {
            flex: 1 !important;
            background: #2C2C2E !important;
            border: 1px solid rgba(255, 255, 255, 0.08) !important;
            border-radius: 20px !important;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.2) !important;
            display: flex !important;
            flex-direction: column !important;
            min-height: 0 !important;
            overflow: hidden !important;
        }
        .markdown-body {
            flex: 1 !important;
            overflow-y: auto !important;
            padding: 30px 40px !important;
            color: #F5F5F7 !important;
            font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif !important;
            line-height: 1.6 !important;
            text-align: left !important;
        }
        .markdown-body h3 {
            font-size: 15px !important;
            font-weight: 700 !important;
            color: #FFFFFF !important;
            margin-top: 24px !important;
            margin-bottom: 12px !important;
            display: flex !important;
            align-items: center !important;
            gap: 8px !important;
            padding-bottom: 8px !important;
            border-bottom: 1px solid rgba(255, 255, 255, 0.08) !important;
            font-family: 'Outfit', sans-serif !important;
        }
        .markdown-body h3:first-child {
            margin-top: 0 !important;
        }
        .markdown-body ul {
            margin: 0 0 16px 0 !important;
            padding-left: 20px !important;
            list-style-type: disc !important;
        }
        .markdown-body li {
            margin-bottom: 8px !important;
            font-size: 13px !important;
            color: #F5F5F7 !important;
        }
        .markdown-body code {
            font-family: SFMono-Regular, Consolas, "Liberation Mono", Menlo, monospace !important;
            font-size: 12px !important;
            background-color: #1C1C1E !important;
            padding: 2px 6px !important;
            border-radius: 6px !important;
            border: 1px solid rgba(255, 255, 255, 0.08) !important;
            color: #0A84FF !important;
            font-weight: 600 !important;
        }
        .markdown-body blockquote {
            margin: 8px 0 !important;
            padding: 10px 16px !important;
            color: #F5F5F7 !important;
            background-color: #1C1C1E !important;
            border-left: 4px solid #FF9F0A !important;
            border-radius: 0 8px 8px 0 !important;
            font-size: 12.5px !important;
            font-style: italic !important;
        }
        .md-order-group {
            margin-bottom: 16px !important;
            border: 1px solid rgba(255, 255, 255, 0.06) !important;
            border-radius: 12px !important;
            padding: 14px !important;
            background: #1C1C1E !important;
        }
        .md-order-header {
            display: flex !important;
            align-items: center !important;
            justify-content: space-between !important;
            margin-bottom: 8px !important;
        }
        .md-order-title {
            font-weight: 700 !important;
            font-size: 13.5px !important;
            color: #0A84FF !important;
        }
        .md-products-list {
            margin: 6px 0 !important;
            padding-left: 0 !important;
            list-style-type: none !important;
        }
        .md-product-row {
            display: flex !important;
            align-items: center !important;
            gap: 8px !important;
            font-size: 12.5px !important;
            margin-bottom: 4px !important;
        }
        .md-qty-tag {
            color: #30D158 !important;
            font-weight: 700 !important;
            background: rgba(48, 209, 88, 0.12) !important;
            padding: 1px 5px !important;
            border-radius: 4px !important;
            font-size: 11px !important;
            border: 1px solid rgba(48, 209, 88, 0.2) !important;
        }
        .md-model-block {
            margin-bottom: 18px !important;
            border: 1px solid rgba(255, 255, 255, 0.06) !important;
            border-radius: 14px !important;
            background: #1C1C1E !important;
            overflow: hidden !important;
        }
        .md-model-header {
            background: #2C2C2E !important;
            padding: 10px 16px !important;
            display: flex !important;
            justify-content: space-between !important;
            align-items: center !important;
            border-bottom: 1px solid rgba(255, 255, 255, 0.06) !important;
            font-weight: 700 !important;
            font-size: 13.5px !important;
            color: #FFFFFF !important;
        }
        .md-model-badge {
            font-size: 11px !important;
            font-weight: 700 !important;
            color: #0A84FF !important;
            background: rgba(10, 132, 255, 0.12) !important;
            border: 1px solid rgba(10, 132, 255, 0.2) !important;
        }
        .md-model-body {
            padding: 12px 16px !important;
        }
        .md-model-row {
            display: flex !important;
            align-items: center !important;
            justify-content: space-between !important;
            padding: 6px 0 !important;
            border-bottom: 1px solid rgba(255, 255, 255, 0.05) !important;
            font-size: 12.5px !important;
        }
        .md-model-row:last-child {
            border-bottom: none !important;
        }
    `;
    document.head.appendChild(style);

    // Show custom toast function
    function showToast(title, body) {
        let toast = document.querySelector('.dexter-toast');
        if (!toast) {
            toast = document.createElement('div');
            toast.className = 'dexter-toast';
            toast.innerHTML = `
                <div class="dexter-toast-icon">
                    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"/></svg>
                </div>
                <div class="dexter-toast-content">
                    <span class="dexter-toast-title"></span>
                    <span class="dexter-toast-body"></span>
                </div>
            `;
            document.body.appendChild(toast);
        }

        toast.querySelector('.dexter-toast-title').innerText = title;
        toast.querySelector('.dexter-toast-body').innerText = body;

        // Force reflow
        toast.offsetHeight;

        toast.classList.add('show');

        setTimeout(() => {
            toast.classList.remove('show');
        }, 3500);
    }

    let noteKeywords = ["notlarkisminayazabilirsiniz", "notlarkismina", "notlarkismi"];
    let customKeywords = ["kisiyeozel"];

    function normalizeKeyword(str) {
        if (!str) return '';
        return str.toLowerCase()
            .replace(/\s+/g, '')
            .replace(/ı/g, 'i')
            .replace(/ğ/g, 'g')
            .replace(/ü/g, 'u')
            .replace(/ş/g, 's')
            .replace(/ö/g, 'o')
            .replace(/ç/g, 'c');
    }

    async function fetchLocalSettings() {
        try {
            const response = await new Promise((resolve) => {
                chrome.runtime.sendMessage({ action: 'fetchSettings' }, (res) => {
                    if (chrome.runtime.lastError) {
                        resolve(null);
                    } else {
                        resolve(res);
                    }
                });
            });
            if (response && response.success && response.settings) {
                const data = response.settings;
                if (data.noteKeywords) {
                    noteKeywords = data.noteKeywords.split(',').map(s => normalizeKeyword(s.trim())).filter(s => s.length > 0);
                }
                if (data.customKeywords) {
                    customKeywords = data.customKeywords.split(',').map(s => normalizeKeyword(s.trim())).filter(s => s.length > 0);
                }
                console.log("[Dexter Extension] Loaded local settings via service worker:", { noteKeywords, customKeywords });
            }
        } catch (e) {
            console.log("[Dexter Extension] Local settings offline or error:", e);
        }
    }

    async function sendToDesktopApp(text) {
        try {
            const response = await new Promise((resolve) => {
                chrome.runtime.sendMessage({ action: 'importOrder', text }, (res) => {
                    if (chrome.runtime.lastError) {
                        resolve(null);
                    } else {
                        resolve(res);
                    }
                });
            });
            if (response && response.success) {
                showToast("Sipariş Aktarıldı", "Sipariş verileri doğrudan Dexter uygulamasına aktarıldı!");
                return true;
            }
        } catch (e) {
            console.log("Dexter app is offline or error occurred:", e);
        }
        return false;
    }

    // Helper to launch desktop app via custom protocol
    function launchDesktopApp(text) {
        try {
            const base64Data = btoa(unescape(encodeURIComponent(text)));
            const protocolUrl = `dexter-dexigner://import/${base64Data}`;
            // Use window.location.href directly to guarantee bypass of iframe sandboxing
            window.location.href = protocolUrl;
        } catch (e) {
            console.error("Failed to launch desktop app via protocol:", e);
        }
    }

    // Check application authentication state before doing actions
    function checkAuthentication(callback) {
        // First check extension's own session in chrome.storage.local
        chrome.storage.local.get(['session'], (localResult) => {
            if (localResult && localResult.session && localResult.session.loggedIn) {
                const session = localResult.session;
                // Double check if expired
                if (session.expiresAt) {
                    const expiryDate = new Date(session.expiresAt);
                    if (expiryDate < new Date()) {
                        // Extension local session expired, fall back to desktop app check
                        performDesktopAppAuthCheck(callback);
                        return;
                    }
                }
                // Valid local session, proceed!
                callback();
            } else {
                // No valid local session, check desktop app
                performDesktopAppAuthCheck(callback);
            }
        });
    }

    function performDesktopAppAuthCheck(callback) {
        chrome.runtime.sendMessage({ action: 'checkAuth' }, (response) => {
            if (chrome.runtime.lastError) {
                console.error("Auth check failed:", chrome.runtime.lastError);
                alert("HATA: Aktif bir üyeliğiniz bulunmamaktadır!\n\nLütfen eklenti logosuna tıklayıp giriş yapın veya masaüstü uygulamasını çalıştırın.");
                return;
            }
            if (response && response.success && response.loggedIn) {
                const session = {
                    loggedIn: true,
                    email: response.email,
                    expiresAt: response.expiresAt || null,
                    userId: response.userId || null,
                    token: response.token || null
                };
                chrome.storage.local.set({ session }, () => {
                    callback();
                });
            } else {
                alert("HATA: Aktif bir üyeliğiniz bulunmamaktadır!\n\nLütfen tarayıcının sağ üst köşesindeki eklenti simgesine tıklayarak giriş yapın.");
            }
        });
    }

    // Helper to parse design code and phone model from title/variant
    function parseCodeAndModel(titleText, variantText) {
        let code = "KOD-YOK";
        let model = "Bilinmeyen Model";
        let productName = titleText || "";

        // 1. Parse design code (e.g. K236) from title or variant
        const combinedTextForCode = (titleText + " " + (variantText || "")).trim();
        const codeMatch = combinedTextForCode.match(/\b(K\d+)\b/i) || combinedTextForCode.match(/\((K\d+)\)/i);
        if (codeMatch) {
            code = codeMatch[1].toUpperCase();
        }

        // Clean design code out of the product name so it doesn't cause extra parentheses
        if (code !== "KOD-YOK") {
            const escapedCode = code.replace(/[-\/\\^$*+?.()|[\]{}]/g, '\\$&');
            productName = productName.replace(new RegExp(`\\(${escapedCode}\\)`, 'gi'), '');
            productName = productName.replace(new RegExp(`\\b${escapedCode}\\b`, 'gi'), '');
            productName = productName.replace(/\s+/g, ' ').trim();
        }

        // 2. Parse phone model
        const combinedTextForModel = (productName + " " + (variantText || "")).toLowerCase();
        const iphoneKeywords = /(iphone\s+)?(17\s*pro\s*max|17\s*pm|17\s*pro|17\s*air|17|16\s*pro\s*max|16\s*pm|16\s*pro|16\s*plus|16\s*e|16|15\s*pro\s*max|15\s*pm|15\s*pro|15|14\s*pro\s*max|14\s*pm|14\s*pro|14\s*plus|14\s*|13\s*pro\s*max|13\s*pm|13\s*pro|13\s*mini|13|12\s*pro\s*max|12\s*pm|12\s*pro|12\s*mini|12|11\s*pro\s*max|11\s*pm|11\s*pro|11|xs\s*max|xs\s*\+|xs|xr|x|8\s*plus|8\s*\+|8|7|6s|6\s*plus|6|se)/gi;
        
        const m = combinedTextForModel.match(iphoneKeywords);
        if (m) {
            let longestMatch = m[0];
            for (const matchStr of m) {
                if (matchStr.length > longestMatch.length) {
                    longestMatch = matchStr;
                }
            }
            
            let formattedModel = longestMatch.replace(/\b\w/g, c => c.toUpperCase()).trim();
            if (!formattedModel.toLowerCase().startsWith('iphone') && !['xs', 'xr', 'x', 'se'].includes(formattedModel.toLowerCase())) {
                formattedModel = "Iphone " + formattedModel;
            }
            model = formattedModel;
        }

        return { productName, code, model };
    }

    // Helper to format order, copy to clipboard, and open the app
    function copyOrderToClipboard(qty, productName, code, model) {
        checkAuthentication(() => {
            qty = qty || "1";
            productName = productName ? productName.trim() : "Telefon Kilifi";
            
            // Clean design code out of the productName to avoid duplicate parenthesized sections
            if (code && code !== 'KOD-YOK') {
                const escapedCode = code.replace(/[-\/\\^$*+?.()|[\]{}]/g, '\\$&');
                productName = productName.replace(new RegExp(`\\(${escapedCode}\\)`, 'gi'), '');
                productName = productName.replace(new RegExp(`\\b${escapedCode}\\b`, 'gi'), '');
                productName = productName.replace(/\s+/g, ' ').trim();
            }

            code = code ? code.trim() : "KOD-YOK";
            model = model ? model.trim() : "Bilinmeyen Model";

            const formatted = `- ${qty}x ${productName} (${code}) (${model})`;
            
            navigator.clipboard.writeText(formatted).then(() => {
                showToast("Sipariş Dexter'a Aktarılıyor", `${model} - ${code} (${qty} Adet) kopyalandı ve uygulama açılıyor.`);
            }).catch(err => {
                console.error("Clipboard copy failed: ", err);
                const textarea = document.createElement('textarea');
                textarea.value = formatted;
                document.body.appendChild(textarea);
                textarea.select();
                document.execCommand('copy');
                document.body.removeChild(textarea);
                showToast("Sipariş Dexter'a Aktarılıyor", `${model} - ${code} (${qty} Adet) kopyalandı ve uygulama açılıyor.`);
            });

            launchDesktopApp(formatted);
        });
    }

    const SUPABASE_URL = "https://pbvelftrjdswqfcjmfit.supabase.co";
    const SUPABASE_ANON_KEY = "sb_publishable_vJxGKyMa489FJpvWaAwZgA_nsSizUQ0";

    // Default configuration (fallback)
    let config = {
        shopify: {
            detailCard: ".Polaris-CardSection_12gvu, .Polaris-Card__Section, [class*=\"OrderDetails\"]",
            header: ".Polaris-Page-Header__TitleWrapper, [class*=\"Header\"]",
            items: ".Polaris-ResourceItem, tr.Polaris-IndexTable__Row, [class*=\"LineItem\"]",
            titleEl: "[class*=\"ProductTitle\"], .Polaris-ResourceItem__Title, td:nth-child(2)",
            qtyEl: "[class*=\"Quantity\"], td:nth-child(3)",
            skuEl: "[class*=\"Sku\"], .sku, .Polaris-TextStyle--variationSubdued",
            variantEl: "[class*=\"VariantTitle\"], .Polaris-TextStyle--variationSubdued",
            variantModelRegex: "(iPhone\\s+\\d+\\s*\\w*\\s*\\w*)"
        },
        shopier: {
            rows: "tr[id^=\"orderRow_\"], .order-item, .showroom-order-row",
            actionCell: "td:last-child, .actions, .order-actions",
            qtyEl: ".qty, .adet, td:nth-child(3)",
            descEl: ".product-name, .urun-adi, td:nth-child(2)"
        }
    };

    // Load configuration from Supabase (Remote Config / Loader pattern)
    async function loadRemoteConfig() {
        try {
            const response = await fetch(`${SUPABASE_URL}/rest/v1/app_templates?key=eq.extension_config`, {
                method: 'GET',
                headers: {
                    'apikey': SUPABASE_ANON_KEY,
                    'Content-Type': 'application/json'
                }
            });
            if (response.ok) {
                const data = await response.json();
                if (data && data.length > 0 && data[0].data) {
                    config = data[0].data;
                    console.log("[Dexter Extension] Remote configuration loaded successfully.");
                }
            }
        } catch (e) {
            console.warn("[Dexter Extension] Failed to load remote config, using local fallbacks.", e);
        }
    }
    // Helper to find Shopier card containers and their order ID headings dynamically
    function getShopierCards() {
        let cards = document.querySelectorAll('.card-description, .card, .panel, .order-card');
        let validCards = [];
        cards.forEach(card => {
            let idEl = card.querySelector('h4#orderid') || card.querySelector('[id="orderid"]');
            
            if (!idEl) {
                let wrapper = card.closest('.card, .panel, tbody, table, .row');
                if (wrapper) {
                    idEl = wrapper.querySelector('h4#orderid') || wrapper.querySelector('[id="orderid"]');
                }
            }
            
            if (!idEl) {
                let allEls = card.querySelectorAll('h4, h3, h5, a, span, div, p');
                for (let el of allEls) {
                    let text = el.textContent.trim();
                    if (el.children.length === 0 && /^#?\d{6,12}$/.test(text)) {
                        idEl = el;
                        break;
                    }
                }
            }
            if (!idEl) {
                let wrapper = card.closest('.card, .panel, tbody, table, .row');
                if (wrapper) {
                    let allEls = wrapper.querySelectorAll('h4, h3, h5, a, span, div, p');
                    for (let el of allEls) {
                        let text = el.textContent.trim();
                        if (el.children.length === 0 && /^#?\d{6,12}$/.test(text)) {
                            idEl = el;
                            break;
                        }
                    }
                }
            }

            if (idEl) {
                validCards.push({ card, idEl });
            }
        });
        
        // Remove duplicate cards (prefer the deepest/most specific card container)
        let uniqueCards = [];
        let seenCards = new Set();
        validCards.forEach(item => {
            let cardEl = item.card;
            if (cardEl.classList.contains('card') && cardEl.querySelector('.card-description')) {
                return;
            }
            if (!seenCards.has(cardEl)) {
                seenCards.add(cardEl);
                uniqueCards.push(item);
            }
        });
        
        return uniqueCards;
    }

    // Helper to parse a single Shopier order card (m/orders.php)
    function parseShopierCard(card) {
        let compiledText = "";
        let cartTbody = card.querySelector('tbody[id="cart_tbody"]');
        if (cartTbody && cartTbody.querySelectorAll('tr').length > 0) {
            let rows = cartTbody.querySelectorAll('tr');
            rows.forEach(row => {
                let style = row.getAttribute('style') || '';
                if (style.includes('display: none')) return;
                
                let subjectEl = row.querySelector('[id="cart_product_subject"]');
                let variantEl = row.querySelector('[id="cart_product_options_variations"]');
                let countEl = row.querySelector('[id="cart_product_count"]');
                
                if (!subjectEl) return;
                let name = subjectEl.textContent.trim();
                let variant = variantEl ? variantEl.textContent.trim() : '';
                let countStr = countEl ? countEl.textContent.trim() : '1';
                let count = parseInt(countStr) || 1;
                
                let parsed = parseCodeAndModel(name, variant);
                compiledText += `- ${count}x ${parsed.productName} (${parsed.code}) (${parsed.model})\n`;
            });
        }
        
        // If compiledText is empty, let's try parsing the labels from the card DOM (e.g. Advanced View or standard elements)
        if (!compiledText.trim()) {
            let productsFound = [];
            let elements = card.querySelectorAll('*');
            elements.forEach(el => {
                let text = el.textContent.trim();
                let isName = text.toLowerCase().startsWith("ürün adı:") || text.toLowerCase().startsWith("product name:");
                if (isName) {
                    let children = el.querySelectorAll('*');
                    let hasChildWithName = Array.from(children).some(child => {
                        let childText = child.textContent.trim().toLowerCase();
                        return childText.startsWith("ürün adı:") || childText.startsWith("product name:");
                    });
                    if (!hasChildWithName) {
                        let prefix = text.toLowerCase().startsWith("ürün adı:") ? "Ürün Adı:" : "Product Name:";
                        let nameVal = text.slice(prefix.length).trim();
                        
                        let qtyVal = 1;
                        let variantVal = "";
                        
                        let parent = el.closest('tr, div.row, td, div') || el.parentElement;
                        if (parent) {
                            let parentTexts = parent.querySelectorAll('*');
                            parentTexts.forEach(pe => {
                                let pText = pe.textContent.trim();
                                if (pText.toLowerCase().startsWith("ürün adedi:") || pText.toLowerCase().startsWith("quantity:")) {
                                    let qPrefix = pText.toLowerCase().startsWith("ürün adedi:") ? "Ürün Adedi:" : "Quantity:";
                                    qtyVal = parseInt(pText.slice(qPrefix.length).trim()) || 1;
                                } else if (pText.toLowerCase().startsWith("varyasyon:") || pText.toLowerCase().startsWith("variation:")) {
                                    let vPrefix = pText.toLowerCase().startsWith("varyasyon:") ? "Varyasyon:" : "Variation:";
                                    variantVal = pText.slice(vPrefix.length).trim();
                                    if (variantVal === "-") variantVal = "";
                                }
                            });
                        }
                        
                        productsFound.push({ name: nameVal, count: qtyVal, variant: variantVal });
                    }
                }
            });
            
            if (productsFound.length > 0) {
                productsFound.forEach(p => {
                    let parsed = parseCodeAndModel(p.name, p.variant);
                    compiledText += `- ${p.count}x ${parsed.productName} (${parsed.code}) (${parsed.model})\n`;
                });
            } else {
                // Fallback to old selector-based parsing
                let subjectEl = card.querySelector('[id="subject"]');
                if (subjectEl) {
                    let name = subjectEl.textContent.trim();
                    let countEl = card.querySelector('[id="product_count"]');
                    let countStr = countEl ? countEl.textContent.trim() : '1';
                    let count = parseInt(countStr) || 1;
                    let variantEl = card.querySelector('[id="variation_list"]');
                    let variant = variantEl ? variantEl.textContent.trim() : '';
                    
                    let parsed = parseCodeAndModel(name, variant);
                    compiledText += `- ${count}x ${parsed.productName} (${parsed.code}) (${parsed.model})\n`;
                }
            }
        }
        
        return compiledText;
    }

    // Helper to parse a single Shopier table row
    function parseShopierRow(row) {
        let qty = "1";
        const qtyEl = row.querySelector(config.shopier.qtyEl);
        if (qtyEl) {
            const m = qtyEl.innerText.match(/\d+/);
            if (m) qty = m[0];
        }

        let productName = "Telefon Kilifi";
        let code = "KOD-YOK";
        let model = "Bilinmeyen Model";

        const descEl = row.querySelector(config.shopier.descEl);
        if (descEl) {
            const fullText = descEl.innerText;
            productName = fullText.split('\n')[0].trim();
            
            let opts = "";
            const optionsMatch = fullText.match(/\(([^)]+)\)/);
            if (optionsMatch) {
                opts = optionsMatch[1];
            }
            
            const parsed = parseCodeAndModel(productName, opts);
            productName = parsed.productName;
            code = parsed.code;
            model = parsed.model;
            
            // Fallback split logic if model or code is still default
            if ((code === "KOD-YOK" || model === "Bilinmeyen Model") && opts) {
                const parts = opts.split(/[-|,]/);
                if (parts.length >= 2) {
                    if (model === "Bilinmeyen Model") model = parts[0].trim();
                    if (code === "KOD-YOK") code = parts[1].replace(/Tasarım|Kod|SKU/gi, '').replace(':', '').trim();
                } else if (model === "Bilinmeyen Model") {
                    model = opts.trim();
                }
            }
        }

        return `- ${qty}x ${productName} (${code}) (${model})\n`;
    }

    // Helper to get status of the card
    function getShopierCardStatus(card) {
        let statusText = "";
        let statusEl = card.querySelector('#order_status_text') || card.querySelector('.order-status') || card.querySelector('[id*="status"]') || card.querySelector('.status');
        if (statusEl) {
            statusText = statusEl.textContent.trim().toUpperCase();
        } else {
            let spans = card.querySelectorAll('span, p, div, td');
            for (let el of spans) {
                if (el.textContent.trim().includes("Durum:")) {
                    let nextEl = el.nextElementSibling || el;
                    statusText = nextEl.textContent.replace("Durum:", "").trim().toUpperCase();
                    break;
                }
            }
        }
        return statusText;
    }

    // Helper to get Customer Note from the card
    function getShopierCustomerNote(card) {
        let note = "";
        let spans = card.querySelectorAll('span, p, div, td');
        for (let el of spans) {
            let text = el.textContent.trim();
            if (text.startsWith("Müşteri Notu:")) {
                note = text.replace("Müşteri Notu:", "").trim();
                break;
            }
        }
        return note;
    }

    // Helper to check special conditions (notes, custom keywords)
    function checkSpecialConditions(text) {
        if (!text) return { isNote: false, isCustom: false };
        let compactText = text.toLowerCase().replace(/\s+/g, '');
        let normalized = compactText
            .replace(/ı/g, 'i')
            .replace(/ğ/g, 'g')
            .replace(/ü/g, 'u')
            .replace(/ş/g, 's')
            .replace(/ö/g, 'o')
            .replace(/ç/g, 'c');
        let isNote = noteKeywords.some(keyword => normalized.includes(keyword));
        let isCustom = customKeywords.some(keyword => normalized.includes(keyword));
        return { isNote, isCustom };
    }

    // Helper to get the Order ID from the card
    function getShopierCardOrderId(card, idEl) {
        if (idEl) {
            let text = idEl.textContent.trim();
            if (text && text !== "Siparişteki ürünü görüntüle") {
                return text;
            }
        }
        let el = card.querySelector('h4#orderid') || card.querySelector('[id="orderid"]');
        if (el) {
            let text = el.textContent.trim();
            if (text && text !== "Siparişteki ürünü görüntüle") return text;
        }

        // Search for purely numeric values or values starting with #
        let h4s = card.querySelectorAll('h4');
        for (let h4 of h4s) {
            let text = h4.textContent.trim();
            if (/^\d+$/.test(text) || text.startsWith('#')) return text;
        }

        let fallbackBtn = card.querySelector('[data-id]');
        if (fallbackBtn) {
            let dataId = fallbackBtn.getAttribute('data-id');
            if (dataId) return "#" + dataId;
        }
        
        return "#BilinmeyenSiparis";
    }

    // Helper to check if open orders filter is active
    function isOpenFilterChecked() {
        const openRadio = document.querySelector('input[name="filtered_selected_order_type"][value="openorders"]') || document.getElementById('radio2');
        return openRadio ? openRadio.checked : false;
    }

    // Helper to open the filter drawer/panel if hidden
    function openFilterPanelIfNeeded() {
        return new Promise((resolve) => {
            const builder = document.getElementById('builder');
            const isOpen = builder && builder.classList.contains('open');
            if (isOpen) {
                resolve(true);
                return;
            }
            
            const filterToggle = document.querySelector('a.builder-toggle[data-toggle-element="#builder"]') || 
                                 document.querySelector('a.builder-toggle') || 
                                 document.querySelector('[data-toggle="quickview"]');
            
            if (filterToggle) {
                console.log("[Dexter Extension] Clicking filter toggle button...");
                filterToggle.click();
                setTimeout(() => resolve(true), 600);
            } else {
                let candidates = document.querySelectorAll('[class*="filter" i], [id*="filter" i], a, button, div');
                for (let el of candidates) {
                    if (el.closest('.filter-sidebar, #filter-sidebar, .modal-content')) continue;
                    let className = String(el.className || '').toLowerCase();
                    let idName = String(el.id || '').toLowerCase();
                    if (className.includes('filter-btn') || className.includes('filter-toggle') || className.includes('filter-trigger')) {
                        el.click();
                        setTimeout(() => resolve(true), 600);
                        return;
                    }
                }
                console.warn("[Dexter Extension] Filter toggle button not found.");
                resolve(false);
            }
        });
    }

    // Automation to check Open Orders radio button and apply filter
    async function applyShopierOpenFilter() {
        console.log("[Dexter Extension] Ensuring filter panel is open...");
        const opened = await openFilterPanelIfNeeded();
        if (!opened) {
            console.warn("[Dexter Extension] Could not open filter panel.");
            return false;
        }
        
        await new Promise(r => setTimeout(r, 200));

        const openRadio = document.querySelector('input[name="filtered_selected_order_type"][value="openorders"]') || document.getElementById('radio2');
        if (openRadio) {
            console.log("[Dexter Extension] Selecting 'Açık siparişler' filter...");
            const label = document.querySelector(`label[for="${openRadio.id}"]`);
            if (label) {
                label.click();
            } else {
                openRadio.click();
            }
            
            await new Promise(r => setTimeout(r, 400));
            
            const applyBtn = document.getElementById('filtered_orders') || document.querySelector('button#filtered_orders');
            if (applyBtn) {
                console.log("[Dexter Extension] Clicking UYGULA to apply open orders filter...");
                applyBtn.click();
                return true;
            } else {
                console.warn("[Dexter Extension] UYGULA button not found.");
            }
        } else {
            console.warn("[Dexter Extension] 'Açık siparişler' radio option not found.");
        }
        return false;
    }

    // Scrapes multiple pages of open orders, matching Tampermonkey script's features
    async function triggerShopierMultiPageScrape() {
        await fetchLocalSettings();
        let progress = document.getElementById('dexter-progress-overlay');
        if (!progress) {
            progress = document.createElement('div');
            progress.id = 'dexter-progress-overlay';
            progress.style.cssText = `
                position: fixed;
                bottom: 24px;
                right: 24px;
                background-color: rgba(10, 10, 12, 0.9);
                backdrop-filter: blur(12px);
                -webkit-backdrop-filter: blur(12px);
                border: 1px solid rgba(255, 255, 255, 0.08);
                color: #FFFFFF;
                padding: 16px 24px;
                border-radius: 14px;
                box-shadow: 0 20px 40px rgba(0,0,0,0.6);
                z-index: 9999999;
                font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
                font-weight: 600;
                font-size: 13px;
                transition: all 0.3s ease;
            `;
            document.body.appendChild(progress);
        }

        let products = {};
        let noteOrders = new Set();
        let customOrders = new Set();
        let refundOrders = new Set();
        let orderNotesMap = {};
        let orderProductsMap = {};
        let orderNoteProductsMap = {};
        let orderCustomProductsMap = {};
        let allOrders = new Set();
        let allProductLines = "";
        let pageNum = 1;
        const maxPagesLimit = 10;

        while (pageNum <= maxPagesLimit) {
            progress.innerText = `Sayfa ${pageNum} taranıyor, lütfen sayfadan ayrılmayın...`;
            
            let shopierCards = getShopierCards();
            if (shopierCards.length === 0) break;

            shopierCards.forEach(({ card, idEl }) => {
                let orderCode = getShopierCardOrderId(card, idEl);
                let statusText = getShopierCardStatus(card);
                let musteriNotuText = getShopierCustomerNote(card);
                
                if (musteriNotuText) {
                    orderNotesMap[orderCode] = musteriNotuText;
                }
                
                let orderIsRefund = statusText.includes("İADE") || statusText.includes("IADE");
                let isClosed = statusText.includes("KAPALI") || statusText.includes("TAMAMLANDI") || statusText.includes("CANCELLED") || statusText.includes("CLOSED");
                
                // Skip closed orders
                if (isClosed) return;

                allOrders.add(orderCode);

                let textContent = card.textContent || "";
                let orderCheck = checkSpecialConditions(textContent);
                let hasCustom = orderCheck.isCustom;

                if (orderIsRefund) refundOrders.add(orderCode);
                if (hasCustom) customOrders.add(orderCode);

                let cardText = parseShopierCard(card);
                if (cardText.trim()) {
                    orderProductsMap[orderCode] = cardText.trim();
                    const lines = cardText.split('\n');
                    lines.forEach(line => {
                        if (!line.trim()) return;
                        const match = line.match(/^-\s*(\d+)x\s*(.*)$/);
                        if (match) {
                            let qty = parseInt(match[1]) || 1;
                            let details = match[2].trim();
                            let productCheck = checkSpecialConditions(details);
                            
                            if (orderIsRefund) {
                                refundOrders.add(orderCode);
                            } else if (productCheck.isNote) {
                                noteOrders.add(orderCode);
                                if (!orderNoteProductsMap[orderCode]) {
                                    orderNoteProductsMap[orderCode] = [];
                                }
                                orderNoteProductsMap[orderCode].push(line);
                            } else if (productCheck.isCustom) {
                                customOrders.add(orderCode);
                                if (!orderCustomProductsMap[orderCode]) {
                                    orderCustomProductsMap[orderCode] = [];
                                }
                                orderCustomProductsMap[orderCode].push(line);
                            } else {
                                // Normal product, add to print queue
                                allProductLines += line + "\n";
                                products[details] = (products[details] || 0) + qty;
                            }
                        }
                    });
                }
            });

            // Find Next Page link
            let activePageEl = document.querySelector('.pagination li.active span.page-link, .pagination li.active a.page-link');
            let activePage = activePageEl ? parseInt(activePageEl.textContent.trim()) : pageNum;
            let nextPageText = String(activePage + 1);
            let nextPageLink = Array.from(document.querySelectorAll('.pagination a.page-link')).find(a => a.textContent.trim() === nextPageText);
            
            if (!nextPageLink) {
                nextPageLink = Array.from(document.querySelectorAll('.pagination a.page-link')).find(a => {
                    let t = a.textContent.trim().toLowerCase();
                    return (t === 'sonraki' || t === '>' || t === '»') && !a.parentElement.classList.contains('disabled');
                });
            }

            if (nextPageLink) {
                pageNum++;
                progress.innerText = `Sayfa ${pageNum}'a geçiliyor...`;
                nextPageLink.click();
                await new Promise(r => setTimeout(r, 2000));
            } else {
                break;
            }
        }

        // Build report summary
        let resultText = "### 📝 Müşteri Notları Olan Siparişler:\n";
        if (noteOrders.size > 0) {
            noteOrders.forEach(id => {
                let noteText = orderNotesMap[id] || "Not belirtilmemiş";
                let prodLines = orderNoteProductsMap[id] || [];
                resultText += `- **Sipariş ${id}**:\n`;
                prodLines.forEach(line => {
                    resultText += `  ${line}\n`;
                });
                resultText += `  > Not: ${noteText}\n`;
            });
        } else {
            resultText += "- Bulunamadı\n";
        }

        resultText += "\n### 🎨 Kişiye Özel Tasarımlar:\n";
        if (customOrders.size > 0) {
            customOrders.forEach(id => {
                let prodLines = orderCustomProductsMap[id] || [];
                resultText += `- **Sipariş ${id}**:\n`;
                prodLines.forEach(line => {
                    resultText += `  ${line}\n`;
                });
            });
        } else {
            resultText += "- Bulunamadı\n";
        }

        resultText += "\n### ↩️ İade Edilen Siparişler:\n";
        if (refundOrders.size > 0) {
            refundOrders.forEach(id => {
                let prodLines = orderProductsMap[id] || "";
                resultText += `- **Sipariş ${id}**:\n`;
                if (prodLines.trim()) {
                    prodLines.split('\n').forEach(line => {
                        if (line.trim()) resultText += `  ${line}\n`;
                    });
                }
            });
        } else {
            resultText += "- Bulunamadı\n";
        }

        resultText += "\n### 📦 Baskı Sırası (Modellere Göre):\n";
        let sortedProducts = Object.keys(products).sort((a, b) => products[b] - products[a]);
        if (sortedProducts.length > 0) {
            let groupedProducts = {};
            const familyOrder = [
                "iPhone 17 Modelleri", "iPhone 16 Modelleri", "iPhone 15 Modelleri", "iPhone 14 Modelleri",
                "iPhone 13 Modelleri", "iPhone 12 Modelleri", "iPhone 11 Modelleri", "iPhone XS Modelleri",
                "iPhone X Modelleri", "iPhone 8 Modelleri", "iPhone 7 Modelleri", "iPhone 6 Modelleri", "Diğer Ürünler"
            ];
            
            function getFamily(key) {
                if (key.includes("iPhone 17")) return "iPhone 17 Modelleri";
                if (key.includes("iPhone 16")) return "iPhone 16 Modelleri";
                if (key.includes("iPhone 15")) return "iPhone 15 Modelleri";
                if (key.includes("iPhone 14")) return "iPhone 14 Modelleri";
                if (key.includes("iPhone 13")) return "iPhone 13 Modelleri";
                if (key.includes("iPhone 12")) return "iPhone 12 Modelleri";
                if (key.includes("iPhone 11")) return "iPhone 11 Modelleri";
                if (key.includes("iPhone XS")) return "iPhone XS Modelleri";
                if (key.includes("iPhone X")) return "iPhone X Modelleri";
                if (key.includes("iPhone 8")) return "iPhone 8 Modelleri";
                if (key.includes("iPhone 7")) return "iPhone 7 Modelleri";
                if (key.includes("iPhone 6")) return "iPhone 6 Modelleri";
                return "Diğer Ürünler";
            }

            function getModelSuffixRank(line) {
                let k = line.toLowerCase();
                if (k.includes("pro max")) return 4;
                if (k.includes("pro")) return 3;
                if (k.includes("mini") || k.includes("plus") || k.includes("16e") || k.includes("air")) return 2;
                return 1;
            }

            function getLineQuantity(line) {
                let m = line.match(/^(\d+)x/);
                return m ? parseInt(m[1]) || 0 : 0;
            }

            sortedProducts.forEach(key => {
                let family = getFamily(key);
                if (!groupedProducts[family]) groupedProducts[family] = [];
                groupedProducts[family].push(`${products[key]}x ${key}`);
            });

            let familyTotals = {};
            for (const [family, lines] of Object.entries(groupedProducts)) {
                let total = 0;
                lines.forEach(line => {
                    total += getLineQuantity(line);
                });
                familyTotals[family] = total;
            }

            let familiesSorted = Object.keys(groupedProducts).sort((a, b) => {
                let totalA = familyTotals[a] || 0;
                let totalB = familyTotals[b] || 0;
                if (totalA !== totalB) {
                    return totalB - totalA;
                }
                let indexA = familyOrder.indexOf(a);
                let indexB = familyOrder.indexOf(b);
                if (indexA === -1) indexA = 999;
                if (indexB === -1) indexB = 999;
                return indexA - indexB;
            });

            familiesSorted.forEach(family => {
                resultText += `\n🔽 **${family} (Toplam: ${familyTotals[family]} Adet)**\n`;
                groupedProducts[family].sort((a, b) => {
                    let rankA = getModelSuffixRank(a);
                    let rankB = getModelSuffixRank(b);
                    if (rankA !== rankB) {
                        return rankA - rankB;
                    }
                    let qtyA = getLineQuantity(a);
                    let qtyB = getLineQuantity(b);
                    if (qtyA !== qtyB) {
                        return qtyB - qtyA;
                    }
                    return a.localeCompare(b);
                });
                groupedProducts[family].forEach(line => { resultText += `- ${line}\n`; });
            });
        } else {
            resultText += "- Ürün bulunamadı.\n";
        }

        if (progress) progress.remove();

        if (allProductLines.trim()) {
            sendToDesktopApp(resultText.trim()).then(success => {
                if (!success) {
                    navigator.clipboard.writeText(resultText.trim()).then(() => {
                        showToast("Tüm Açık Siparişler Tarandı", "Özet panoya kopyalandı ve uygulama açılıyor.");
                    }).catch(err => {
                        console.error(err);
                        showToast("Tüm Açık Siparişler Tarandı", "Özet panoya kopyalandı ve uygulama açılıyor.");
                    });
                    launchDesktopApp(allProductLines.trim());
                }
                showScrapeSummaryModal(resultText.trim(), noteOrders, customOrders, refundOrders, products, orderNotesMap, allOrders.size, orderProductsMap);
            });
        } else {
            showToast("Sipariş Bulunamadı", "Açık sipariş verilerinden ürün detayları çözümlenemedi.");
        }
    }

    function showScrapeSummaryModal(reportText, noteOrders, customOrders, refundOrders, products, orderNotesMap, totalOrdersCount, orderProductsMap) {
        let existing = document.querySelector('.apple-summary-overlay');
        if (existing) existing.remove();

        let overlay = document.createElement('div');
        overlay.className = 'apple-summary-overlay';

        let panel = document.createElement('div');
        panel.className = 'apple-summary-panel';

        let headerRow = document.createElement('div');
        headerRow.className = 'apple-summary-header';

        let headerLeft = document.createElement('div');
        headerLeft.className = 'apple-summary-header-left';

        let windowControls = document.createElement('div');
        windowControls.className = 'window-controls';
        windowControls.innerHTML = `
            <span class="control-dot close" title="Kapat"></span>
            <span class="control-dot minimize"></span>
            <span class="control-dot maximize"></span>
        `;
        windowControls.querySelector('.close').onclick = function() {
            overlay.classList.remove('show');
            setTimeout(() => overlay.remove(), 300);
        };
        headerLeft.appendChild(windowControls);

        let iconBox = document.createElement('div');
        iconBox.className = 'header-icon-box';
        iconBox.innerHTML = `<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/></svg>`;
        headerLeft.appendChild(iconBox);

        let titleContainer = document.createElement('div');
        titleContainer.className = 'header-title-container';

        let title = document.createElement('h2');
        title.className = 'apple-summary-title';
        title.innerText = 'Sipariş Tarama Raporu';
        titleContainer.appendChild(title);

        let subtitle = document.createElement('span');
        subtitle.className = 'apple-summary-subtitle';
        subtitle.innerText = 'Siparişlerinizi markdown formatında kopyalayın veya okuyun.';
        titleContainer.appendChild(subtitle);

        headerLeft.appendChild(titleContainer);
        headerRow.appendChild(headerLeft);

        let btnGroup = document.createElement('div');
        btnGroup.className = 'apple-summary-buttons';

        let copyBtn = document.createElement('button');
        copyBtn.className = 'apple-summary-btn apple-summary-btn-copy';
        copyBtn.innerHTML = `<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><rect x="9" y="9" width="13" height="13" rx="2" ry="2"/><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"/></svg> Raporu Kopyala`;
        copyBtn.onclick = function() {
            navigator.clipboard.writeText(reportText).then(() => {
                copyBtn.innerHTML = `<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="#30D158" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"/></svg> Kopyalandı!`;
                copyBtn.style.color = '#30D158';
                setTimeout(() => {
                    copyBtn.innerHTML = `<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><rect x="9" y="9" width="13" height="13" rx="2" ry="2"/><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"/></svg> Raporu Kopyala`;
                    copyBtn.style.color = '';
                }, 2000);
            });
        };
        btnGroup.appendChild(copyBtn);

        let closeBtn = document.createElement('button');
        closeBtn.className = 'apple-summary-btn apple-summary-btn-close';
        closeBtn.innerHTML = `<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg> Kapat`;
        closeBtn.onclick = function() {
            overlay.classList.remove('show');
            setTimeout(() => overlay.remove(), 300);
        };
        btnGroup.appendChild(closeBtn);
        headerRow.appendChild(btnGroup);

        // Calculate total products count
        let totalProductsCount = 0;
        Object.keys(products).forEach(key => {
            totalProductsCount += products[key];
        });

        // Stats row HTML
        let statsRow = document.createElement('div');
        statsRow.className = 'dexter-stats-row';
        statsRow.innerHTML = `
            <div class="stat-item total-orders">
                <div class="stat-icon-wrapper">
                    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><circle cx="9" cy="21" r="1"/><circle cx="20" cy="21" r="1"/><path d="M1 1h4l2.68 13.39a2 2 0 0 0 2 1.61h9.72a2 2 0 0 0 2-1.61L23 6H6"/></svg>
                </div>
                <div class="stat-text-wrapper">
                    <span class="stat-val">${totalOrdersCount || 0}</span>
                    <span class="stat-lbl">Taranan Sipariş</span>
                </div>
            </div>
            <div class="stat-item total-items">
                <div class="stat-icon-wrapper">
                    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><polyline points="23 6 13.5 15.5 8.5 10.5 1 18"/><polyline points="17 6 23 6 23 12"/></svg>
                </div>
                <div class="stat-text-wrapper">
                    <span class="stat-val">${totalProductsCount}</span>
                    <span class="stat-lbl">Toplam Kılıf</span>
                </div>
            </div>
            <div class="stat-item note-orders">
                <div class="stat-icon-wrapper">
                    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/></svg>
                </div>
                <div class="stat-text-wrapper">
                    <span class="stat-val">${noteOrders.size}</span>
                    <span class="stat-lbl">Notlu Sipariş</span>
                </div>
            </div>
            <div class="stat-item custom-orders">
                <div class="stat-icon-wrapper">
                    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg>
                </div>
                <div class="stat-text-wrapper">
                    <span class="stat-val">${customOrders.size}</span>
                    <span class="stat-lbl">Kişiye Özel</span>
                </div>
            </div>
            <div class="stat-item refund-orders">
                <div class="stat-icon-wrapper">
                    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M3 2v6h6"/><path d="M3 13a9 9 0 1 0 3-7.7L3 8"/></svg>
                </div>
                <div class="stat-text-wrapper">
                    <span class="stat-val">${refundOrders.size}</span>
                    <span class="stat-lbl">İade Sipariş</span>
                </div>
            </div>
        `;

        let contentWrapper = document.createElement('div');
        contentWrapper.className = 'apple-summary-content';
        contentWrapper.style.cssText = 'flex: 1; display: flex; flex-direction: column; min-height: 0;';

        let preElement = document.createElement('pre');
        preElement.className = 'apple-summary-pre';
        preElement.style.cssText = 'flex: 1; margin: 0; overflow-y: auto; white-space: pre-wrap; font-size: 12px; font-family: SFMono-Regular, Consolas, "Liberation Mono", Menlo, monospace; padding: 15px; border-radius: 12px; background: #F5F5F7; border: 1px solid rgba(0,0,0,0.06); color: #1D1D1F; line-height: 1.5; text-align: left;';
        preElement.textContent = reportText;

        contentWrapper.appendChild(preElement);

        panel.appendChild(headerRow);
        panel.appendChild(statsRow);
        panel.appendChild(contentWrapper);
        overlay.appendChild(panel);
        document.body.appendChild(overlay);

        // Force reflow & animate
        overlay.offsetHeight;
        overlay.classList.add('show');
    }

    // 1. SHOPIER PARSER
    let isAutoScanRunning = false;
    function initShopier() {
        setInterval(async () => {
            // Check if we have a pending auto-scan from a filter reload
            if (sessionStorage.getItem('dexter_scanning') === 'true' && !isAutoScanRunning) {
                isAutoScanRunning = true;
                sessionStorage.removeItem('dexter_scanning');
                console.log("[Dexter Extension] Resuming multi-page scrape after filter reload...");
                await triggerShopierMultiPageScrape();
                isAutoScanRunning = false;
            }

            // Find target element to inject next to
            const filterToggle = document.querySelector('a.builder-toggle[data-toggle-element="#builder"]') || 
                                 document.querySelector('a.builder-toggle') || 
                                 document.querySelector('[data-toggle="quickview"]') ||
                                 document.querySelector('.builder-toggle');

            if (!filterToggle) return;

            // Check if already injected
            if (document.getElementById('dexter-shopier-bulk-btn')) {
                return; // already injected
            }

            // Create bulk button
            const btn = document.createElement('button');
            btn.id = 'dexter-shopier-bulk-btn';
            btn.className = 'dexter-premium-bulk-btn';
            btn.type = 'button';
            btn.innerHTML = `
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
                    <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/>
                    <polyline points="7 10 12 15 17 10"/>
                    <line x1="12" y1="15" x2="12" y2="3"/>
                </svg>
                Dexigner'a Aktar
            `;

            // Style adjustments to make it align nicely
            btn.style.cssText += 'margin-right: 12px; vertical-align: middle; height: 38px; display: inline-flex; align-items: center; justify-content: center;';

            // Click handler
            btn.addEventListener('click', (e) => {
                e.preventDefault();
                e.stopPropagation();
                runShopierScrape();
            });

            // Insert before filterToggle
            filterToggle.parentNode.insertBefore(btn, filterToggle);
            console.log("[Dexter Extension] Injected Shopier inline button successfully next to:", filterToggle);
        }, 1500);
    }

    function initShopify() {
        setInterval(() => {
            const url = window.location.href;
            const isOrdersListPage = url.includes('/orders') && !url.match(/\/orders\/\d+(\/|$)/);
            
            if (!isOrdersListPage) {
                const existing = document.getElementById('dexter-shopify-inline-btn-wrapper');
                if (existing) existing.remove();
                return;
            }

            let targetBtn = null;
            let isExportBtn = false;
            
            function findElementRecursively(root, predicate) {
                if (!root) return null;
                
                if (root.shadowRoot) {
                    const found = findElementRecursively(root.shadowRoot, predicate);
                    if (found) return found;
                }
                
                if (root.children) {
                    for (const child of root.children) {
                        const found = findElementRecursively(child, predicate);
                        if (found) return found;
                    }
                }
                
                if (predicate(root)) return root;
                return null;
            }

            function getOutermostButtonOrHost(el) {
                let current = el;
                let lastButtonOrHost = null;
                while (current) {
                    const tagName = current.tagName ? current.tagName.toLowerCase() : '';
                    const isButtonTag = ['button', 'a', 'ui-button', 's-button', 'polaris-button'].includes(tagName) || 
                                        (tagName.startsWith('ui-') && tagName.includes('button')) || 
                                        (tagName.startsWith('s-') && tagName.includes('button')) || 
                                        (tagName.startsWith('polaris-') && tagName.includes('button'));
                    const isButtonRoleOrClass = (current.getAttribute && current.getAttribute('role') === 'button') || 
                                                 (current.classList && (current.classList.contains('Polaris-Button') || current.classList.contains('Polaris-Button-default')));
                    
                    if (isButtonTag || isButtonRoleOrClass) {
                        lastButtonOrHost = current;
                    }
                    
                    if (current.parentNode) {
                        current = current.parentNode;
                    } else if (current.host) {
                        current = current.host;
                    } else {
                        break;
                    }
                }
                return lastButtonOrHost || el;
            }

            const normalizeTextForMatch = (str) => {
                if (!str) return '';
                return str.toLowerCase()
                    .replace(/ı/g, 'i')
                    .replace(/ğ/g, 'g')
                    .replace(/ü/g, 'u')
                    .replace(/ş/g, 's')
                    .replace(/ö/g, 'o')
                    .replace(/ç/g, 'c')
                    .replace(/[^a-z0-9]/gi, '')
                    .trim();
            };

            const textMatches = (el, words) => {
                const text = normalizeTextForMatch(el.innerText || el.textContent || '');
                return words.some(word => text.includes(word));
            };

            let foundElement = findElementRecursively(document.body, (el) => {
                if (el.tagName && ['button', 'a', 'span', 'div', 'ui-button', 's-button'].includes(el.tagName.toLowerCase())) {
                    return textMatches(el, ['disaaktar', 'export', 'exportorders', 'siparisleridisaaktar']);
                }
                return false;
            });

            if (foundElement) {
                targetBtn = getOutermostButtonOrHost(foundElement);
                isExportBtn = true;
            } else {
                foundElement = findElementRecursively(document.body, (el) => {
                    if (el.tagName && ['button', 'a', 'span', 'div', 'ui-button', 's-button'].includes(el.tagName.toLowerCase())) {
                        return textMatches(el, ['dahafazlaislem', 'moreactions', 'digerislemler', 'diger']);
                    }
                    return false;
                });
                if (foundElement) {
                    targetBtn = getOutermostButtonOrHost(foundElement);
                } else {
                    foundElement = findElementRecursively(document.body, (el) => {
                        if (el.tagName && ['button', 'a', 'span', 'div', 'ui-button', 's-button'].includes(el.tagName.toLowerCase())) {
                            return textMatches(el, ['siparisolustur', 'createorder']);
                        }
                        return false;
                    });
                    if (foundElement) {
                        targetBtn = getOutermostButtonOrHost(foundElement);
                    }
                }
            }

            if (!targetBtn) return;

            const parent = targetBtn.parentNode;
            if (parent && parent.querySelector('#dexter-shopify-inline-btn-wrapper')) {
                return;
            }

            const duplicates = document.querySelectorAll('#dexter-shopify-inline-btn-wrapper');
            duplicates.forEach(d => d.remove());

            const wrapper = document.createElement('div');
            wrapper.id = 'dexter-shopify-inline-btn-wrapper';
            wrapper.className = 'dexter-shopify-btn-wrapper';

            wrapper.innerHTML = `
                <svg class="dexter-shopify-btn-border-svg" width="100%" height="100%" style="position: absolute; top: 0; left: 0; pointer-events: none; width: 100%; height: 100%;">
                    <rect class="bg-rect" x="0.75" y="0.75" width="calc(100% - 1.5px)" height="calc(100% - 1.5px)" rx="8" ry="8" fill="none" stroke="rgba(255, 255, 255, 0.12)" stroke-width="1.5px" />
                    <rect class="glow-rect" x="0.75" y="0.75" width="calc(100% - 1.5px)" height="calc(100% - 1.5px)" rx="8" ry="8" fill="none" stroke="#0A84FF" stroke-width="1.5px" stroke-dasharray="100 100" stroke-dashoffset="0" style="opacity: 0; transition: opacity 0.3s;" />
                </svg>
                <button id="dexter-shopify-inline-btn" type="button">
                    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
                        <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/>
                        <polyline points="7 10 12 15 17 10"/>
                        <line x1="12" y1="15" x2="12" y2="3"/>
                    </svg>
                    Dexigner'a Aktar
                </button>
            `;

            const btn = wrapper.querySelector('#dexter-shopify-inline-btn');
            const glowRect = wrapper.querySelector('.glow-rect');
            btn.addEventListener('mouseenter', () => {
                glowRect.style.opacity = '1';
            });
            btn.addEventListener('mouseleave', () => {
                glowRect.style.opacity = '0';
            });

            btn.addEventListener('click', (e) => {
                e.preventDefault();
                e.stopPropagation();
                runShopifyScrape();
            });

            if (isExportBtn) {
                targetBtn.parentNode.insertBefore(wrapper, targetBtn.nextSibling);
            } else {
                targetBtn.parentNode.insertBefore(wrapper, targetBtn);
            }
            console.log("[Dexter Extension] Injected Shopify inline button successfully next to:", targetBtn);
        }, 1500);
    }

    function runShopierScrape() {
        checkAuthentication(async () => {
            let alreadyFiltered = isOpenFilterChecked();
            if (alreadyFiltered) {
                console.log("[Dexter Extension] Open orders filter is already applied. Scanning immediately...");
                triggerShopierMultiPageScrape();
            } else {
                console.log("[Dexter Extension] Applying open orders filter before scanning...");
                sessionStorage.setItem('dexter_scanning', 'true');
                let applied = await applyShopierOpenFilter();
                if (!applied) {
                    sessionStorage.removeItem('dexter_scanning');
                    triggerShopierMultiPageScrape();
                }
            }
        });
    }

    // Helper to parse line items on Shopify details page/modal
    function triggerShopifyParse(items) {
        let compiledText = "";
        items.forEach(item => {
            let title = "";
            let qty = "1";
            let model = "Bilinmeyen Model";
            let code = "KOD-YOK";

            // Title extraction
            const titleSelectors = [
                config.shopify.titleEl,
                '[class*="ProductTitle"]',
                '.Polaris-ResourceItem__Title',
                '[class*="title"]',
                'a[href*="/products/"]',
                '.Polaris-Link',
                'td:nth-child(2)',
                'strong',
                'a'
            ];
            for (const sel of titleSelectors) {
                if (!sel) continue;
                const el = item.querySelector(sel);
                if (el && el.innerText.trim()) {
                    title = el.innerText.split('\n')[0].trim();
                    break;
                }
            }

            if (!title) return;

            // Quantity extraction
            const qtySelectors = [
                config.shopify.qtyEl,
                '[class*="Quantity"]',
                'td:nth-child(3)',
                '[class*="quantity"]',
                '.Polaris-IndexTable__TableCell:nth-child(3)',
                '.qty',
                '.adet'
            ];
            for (const sel of qtySelectors) {
                if (!sel) continue;
                const el = item.querySelector(sel);
                if (el && el.innerText.trim()) {
                    const m = el.innerText.match(/\d+/);
                    if (m) {
                        qty = m[0];
                        break;
                    }
                }
            }

            // SKU/Code extraction (official field)
            let skuCode = "";
            const skuSelectors = [
                config.shopify.skuEl,
                '[class*="Sku"]',
                '.sku',
                '.Polaris-TextStyle--variationSubdued',
                '[class*="sku"]',
                'span'
            ];
            for (const sel of skuSelectors) {
                if (!sel) continue;
                const el = item.querySelector(sel);
                if (el && (el.innerText.includes('SKU') || el.innerText.match(/[A-Z0-9-]{4,}/))) {
                    skuCode = el.innerText.replace(/SKU|Kod|Sku/gi, '').replace(':', '').trim();
                    break;
                }
            }

            // Variant extraction
            const variantSelectors = [
                config.shopify.variantEl,
                '[class*="VariantTitle"]',
                '.Polaris-TextStyle--variationSubdued',
                '[class*="variant"]',
                'p'
            ];
            let variantText = "";
            for (const sel of variantSelectors) {
                if (!sel) continue;
                const el = item.querySelector(sel);
                if (el && el.innerText.trim()) {
                    variantText += " " + el.innerText;
                }
            }

            // Parse code & model using our smart helper
            const parsed = parseCodeAndModel(title, variantText);
            
            // If parsed code from title/variant is KOD-YOK, fallback to official SKU code (if valid and not KOD-YOK)
            if (parsed.code === "KOD-YOK" && skuCode && skuCode.toUpperCase() !== "KOD-YOK") {
                parsed.code = skuCode;
            }
            
            // Clean code out of parsed title if it was skuCode
            if (parsed.code !== "KOD-YOK") {
                const escapedCode = parsed.code.replace(/[-\/\\^$*+?.()|[\]{}]/g, '\\$&');
                parsed.productName = parsed.productName.replace(new RegExp(`\\(${escapedCode}\\)`, 'gi'), '');
                parsed.productName = parsed.productName.replace(new RegExp(`\\b${escapedCode}\\b`, 'gi'), '');
                parsed.productName = parsed.productName.replace(/\s+/g, ' ').trim();
            }

            compiledText += `- ${qty}x ${parsed.productName} (${parsed.code}) (${parsed.model})\n`;
        });

        if (compiledText.trim()) {
            sendToDesktopApp(compiledText.trim()).then(success => {
                if (!success) {
                    navigator.clipboard.writeText(compiledText.trim()).then(() => {
                        showToast("Siparişler Dexter'a Aktarılıyor", `Tüm siparişler (${items.length} adet) kopyalandı ve uygulama açılıyor.`);
                    }).catch(err => {
                        console.error(err);
                        showToast("Siparişler Dexter'a Aktarılıyor", `Tüm siparişler (${items.length} adet) kopyalandı ve uygulama açılıyor.`);
                    });
                    launchDesktopApp(compiledText.trim());
                }
            });
        } else {
            showToast("Sipariş Bulunamadı", "Lütfen sipariş detay sayfasında veya modalında olduğunuzdan emin olun.");
        }
    }

    function runShopifyScrape() {
        try {
            const url = window.location.href;
            
            // --- 1. DETAILS PAGE / MODAL PARSER ---
            const isDetailPage = url.match(/\/orders\/\d+(\/|$)/) !== null;
            const activeModal = document.querySelector('.Polaris-Modal, [role="dialog"], .Polaris-Sheet, [class*="Modal"], [class*="Sheet"]');
            
            let detailItems = [];
            
            if (isDetailPage || activeModal) {
                const searchContainer = activeModal || document;
                const detailItemSelectors = [
                    config.shopify.items,
                    '.Polaris-ResourceItem',
                    '[class*="LineItem"]',
                    '.Polaris-IndexTable__TableRow',
                    '.Polaris-LegacyCard tr',
                    'tr'
                ];

                for (const sel of detailItemSelectors) {
                    if (!sel) continue;
                    const found = searchContainer.querySelectorAll(sel);
                    const valid = Array.from(found).filter(item => {
                        const text = item.innerText || '';
                        if (item.querySelector('th') || item.tagName === 'TH') return false;
                        
                        const isInsideDetailsCard = (isDetailPage || activeModal) ? true : item.closest('.Polaris-CardSection_12gvu, .Polaris-Card__Section, [class*="OrderDetails"], .Polaris-LegacyCard, [class*="LineItems"], [class*="order-details"]');
                        const hasProductIdentifiers = text.includes('SKU') || text.match(/[A-Z0-9-]{4,}/) || text.includes('TL') || text.includes('$') || text.includes('Adet') || text.includes('x') || text.includes('€');
                        return isInsideDetailsCard && text.trim().length > 0 && hasProductIdentifiers;
                    });
                    if (valid.length > 0) {
                        detailItems = valid;
                        break;
                    }
                }
            }

            if (detailItems.length > 0) {
                checkAuthentication(() => {
                    triggerShopifyParse(detailItems);
                });
            } else {
                checkAuthentication(() => {
                    // Try fetching the orders JSON directly from the Shopify Admin REST API!
                    let apiUrl = window.location.origin + "/admin/api/unstable/orders.json?limit=250&status=open";
                    const path = window.location.pathname;
                    const storeMatch = path.match(/^\/store\/[^/]+/);
                    if (storeMatch) {
                        apiUrl = window.location.origin + storeMatch[0] + "/api/unstable/orders.json?limit=250&status=open";
                    }

                    let progress = document.getElementById('dexter-progress-overlay');
                    if (!progress) {
                        progress = document.createElement('div');
                        progress.id = 'dexter-progress-overlay';
                        progress.style.cssText = `
                            position: fixed;
                            bottom: 24px;
                            right: 24px;
                            background-color: rgba(10, 10, 12, 0.9);
                            backdrop-filter: blur(12px);
                            -webkit-backdrop-filter: blur(12px);
                            border: 1px solid rgba(255, 255, 255, 0.08);
                            color: #FFFFFF;
                            padding: 16px 24px;
                            border-radius: 14px;
                            box-shadow: 0 20px 40px rgba(0,0,0,0.6);
                            z-index: 9999999;
                            font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
                            font-weight: 600;
                            font-size: 13px;
                            transition: all 0.3s ease;
                        `;
                        document.body.appendChild(progress);
                    }
                    progress.innerText = "Siparişler çekiliyor, lütfen bekleyin...";

                    fetch(apiUrl)
                        .then(res => {
                            if (!res.ok) throw new Error("Shopify API responded with status " + res.status);
                            return res.json();
                        })
                        .then(data => {
                            if (!data || !data.orders) {
                                throw new Error("Invalid orders payload structure");
                            }

                            // Check if user selected any orders on screen
                            let allRows = [];
                            function findRows(node) {
                                if (!node) return;
                                if (node.querySelectorAll) {
                                    const res = node.querySelectorAll('tr.Polaris-IndexTable__Row, [class*="IndexTable__Row"], tr');
                                    if (res.length > 0) allRows = allRows.concat(Array.from(res));
                                }
                                if (node.children) {
                                    for (const child of node.children) findRows(child);
                                }
                                if (node.shadowRoot) findRows(node.shadowRoot);
                            }
                            findRows(document.body);

                            let selectedOrderNames = [];
                            allRows.forEach(row => {
                                const checkbox = row.querySelector('input[type="checkbox"]');
                                const isSelected = row.classList.contains('Polaris-IndexTable__TableRow--selected') || 
                                                 row.classList.contains('Polaris-IndexTable__Row--selected') || 
                                                 (checkbox && checkbox.checked);
                                if (isSelected) {
                                    const text = row.innerText || '';
                                    const m = text.match(/#\d+/);
                                    if (m) selectedOrderNames.push(m[0]);
                                }
                            });

                            let ordersToParse = data.orders;
                            const isFiltered = selectedOrderNames.length > 0;
                            if (isFiltered) {
                                ordersToParse = data.orders.filter(o => selectedOrderNames.includes(o.name));
                            }

                            let products = {};
                            let noteOrders = new Set();
                            let customOrders = new Set();
                            let refundOrders = new Set();
                            let orderNotesMap = {};
                            let orderProductsMap = {};
                            let orderNoteProductsMap = {};
                            let orderCustomProductsMap = {};
                            let allOrders = new Set();
                            let allProductLines = "";

                            ordersToParse.forEach(order => {
                                const orderCode = order.name || String(order.id);
                                allOrders.add(orderCode);

                                let musteriNotuText = (order.note || "").trim();
                                if (musteriNotuText) {
                                    orderNotesMap[orderCode] = musteriNotuText;
                                }

                                let orderIsRefund = (order.cancelled_at !== null) || (order.financial_status === "refunded") || (order.financial_status === "partially_refunded");
                                if (orderIsRefund) refundOrders.add(orderCode);

                                let cardText = "";
                                if (order.line_items) {
                                    order.line_items.forEach(item => {
                                        const title = item.title || "Telefon Kilifi";
                                        const qty = item.quantity || 1;
                                        const skuCode = item.sku || "";
                                        const variantText = item.variant_title || "";

                                        const parsed = parseCodeAndModel(title, variantText);
                                        
                                        if (parsed.code === "KOD-YOK" && skuCode && skuCode.toUpperCase() !== "KOD-YOK") {
                                            parsed.code = skuCode;
                                        }
                                        
                                        if (parsed.code !== "KOD-YOK") {
                                            const escapedCode = parsed.code.replace(/[-\/\\^$*+?.()|[\\\]{}]/g, '\\$&');
                                            parsed.productName = parsed.productName.replace(new RegExp(`\\(${escapedCode}\\)`, 'gi'), '');
                                            parsed.productName = parsed.productName.replace(new RegExp(`\\b${escapedCode}\\b`, 'gi'), '');
                                            parsed.productName = parsed.productName.replace(/\s+/g, ' ').trim();
                                        }

                                        const line = `- ${qty}x ${parsed.productName} (${parsed.code}) (${parsed.model})`;
                                        cardText += line + "\n";
                                    });
                                }

                                if (cardText.trim()) {
                                    orderProductsMap[orderCode] = cardText.trim();
                                    const lines = cardText.split('\n');
                                    lines.forEach(line => {
                                        if (!line.trim()) return;
                                        const match = line.match(/^-\s*(\d+)x\s*(.*)$/);
                                        if (match) {
                                            let qty = parseInt(match[1]) || 1;
                                            let details = match[2].trim();
                                            
                                            let productCheck = checkSpecialConditions(details + " " + musteriNotuText);
                                            
                                            if (orderIsRefund) {
                                                refundOrders.add(orderCode);
                                            } else if (productCheck.isNote || musteriNotuText) {
                                                noteOrders.add(orderCode);
                                                if (!orderNoteProductsMap[orderCode]) {
                                                    orderNoteProductsMap[orderCode] = [];
                                                }
                                                orderNoteProductsMap[orderCode].push(line);
                                            } else if (productCheck.isCustom) {
                                                customOrders.add(orderCode);
                                                if (!orderCustomProductsMap[orderCode]) {
                                                    orderCustomProductsMap[orderCode] = [];
                                                }
                                                orderCustomProductsMap[orderCode].push(line);
                                            } else {
                                                allProductLines += line + "\n";
                                                products[details] = (products[details] || 0) + qty;
                                            }
                                        }
                                    });
                                }
                            });

                            let resultText = "### 📝 Müşteri Notları Olan Siparişler:\n";
                            if (noteOrders.size > 0) {
                                noteOrders.forEach(id => {
                                    let noteText = orderNotesMap[id] || "Not belirtilmemiş";
                                    let prodLines = orderNoteProductsMap[id] || [];
                                    resultText += `- **Sipariş ${id}**:\n`;
                                    prodLines.forEach(line => {
                                        resultText += `  ${line}\n`;
                                    });
                                    resultText += `  > Not: ${noteText}\n`;
                                });
                            } else {
                                resultText += "- Bulunamadı\n";
                            }

                            resultText += "\n### 🎨 Kişiye Özel Tasarımlar:\n";
                            if (customOrders.size > 0) {
                                customOrders.forEach(id => {
                                    let prodLines = orderCustomProductsMap[id] || [];
                                    resultText += `- **Sipariş ${id}**:\n`;
                                    prodLines.forEach(line => {
                                        resultText += `  ${line}\n`;
                                    });
                                });
                            } else {
                                resultText += "- Bulunamadı\n";
                            }

                            resultText += "\n### ↩️ İade Edilen Siparişler:\n";
                            if (refundOrders.size > 0) {
                                refundOrders.forEach(id => {
                                    let prodLines = orderProductsMap[id] || "";
                                    resultText += `- **Sipariş ${id}**:\n`;
                                    if (prodLines.trim()) {
                                        prodLines.split('\n').forEach(line => {
                                            if (line.trim()) resultText += `  ${line}\n`;
                                        });
                                    }
                                });
                            } else {
                                resultText += "- Bulunamadı\n";
                            }

                            resultText += "\n### 📦 Baskı Sırası (Modellere Göre):\n";
                            let sortedProducts = Object.keys(products).sort((a, b) => products[b] - products[a]);
                            if (sortedProducts.length > 0) {
                                let groupedProducts = {};
                                const familyOrder = [
                                    "iPhone 17 Modelleri", "iPhone 16 Modelleri", "iPhone 15 Modelleri", "iPhone 14 Modelleri",
                                    "iPhone 13 Modelleri", "iPhone 12 Modelleri", "iPhone 11 Modelleri", "iPhone XS Modelleri",
                                    "iPhone X Modelleri", "iPhone 8 Modelleri", "iPhone 7 Modelleri", "iPhone 6 Modelleri", "Diğer Ürünler"
                                ];
                                
                                function getFamily(key) {
                                    if (key.includes("iPhone 17")) return "iPhone 17 Modelleri";
                                    if (key.includes("iPhone 16")) return "iPhone 16 Modelleri";
                                    if (key.includes("iPhone 15")) return "iPhone 15 Modelleri";
                                    if (key.includes("iPhone 14")) return "iPhone 14 Modelleri";
                                    if (key.includes("iPhone 13")) return "iPhone 13 Modelleri";
                                    if (key.includes("iPhone 12")) return "iPhone 12 Modelleri";
                                    if (key.includes("iPhone 11")) return "iPhone 11 Modelleri";
                                    if (key.includes("iPhone XS")) return "iPhone XS Modelleri";
                                    if (key.includes("iPhone X")) return "iPhone X Modelleri";
                                    if (key.includes("iPhone 8")) return "iPhone 8 Modelleri";
                                    if (key.includes("iPhone 7")) return "iPhone 7 Modelleri";
                                    if (key.includes("iPhone 6")) return "iPhone 6 Modelleri";
                                    return "Diğer Ürünler";
                                }

                                function getModelSuffixRank(line) {
                                    let k = line.toLowerCase();
                                    if (k.includes("pro max")) return 4;
                                    if (k.includes("pro")) return 3;
                                    if (k.includes("mini") || k.includes("plus") || k.includes("16e") || k.includes("air")) return 2;
                                    return 1;
                                }

                                function getLineQuantity(line) {
                                    let m = line.match(/^(\d+)x/);
                                    return m ? parseInt(m[1]) || 0 : 0;
                                }

                                sortedProducts.forEach(key => {
                                    let family = getFamily(key);
                                    if (!groupedProducts[family]) groupedProducts[family] = [];
                                    groupedProducts[family].push(`${products[key]}x ${key}`);
                                });

                                let familyTotals = {};
                                for (const [family, lines] of Object.entries(groupedProducts)) {
                                    let total = 0;
                                    lines.forEach(line => {
                                        total += getLineQuantity(line);
                                    });
                                    familyTotals[family] = total;
                                }

                                let familiesSorted = Object.keys(groupedProducts).sort((a, b) => {
                                    let totalA = familyTotals[a] || 0;
                                    let totalB = familyTotals[b] || 0;
                                    if (totalA !== totalB) {
                                        return totalB - totalA;
                                    }
                                    let indexA = familyOrder.indexOf(a);
                                    let indexB = familyOrder.indexOf(b);
                                    if (indexA === -1) indexA = 999;
                                    if (indexB === -1) indexB = 999;
                                    return indexA - indexB;
                                });

                                familiesSorted.forEach(family => {
                                    resultText += `\n🔽 **${family} (Toplam: ${familyTotals[family]} Adet)**\n`;
                                    groupedProducts[family].sort((a, b) => {
                                        let rankA = getModelSuffixRank(a);
                                        let rankB = getModelSuffixRank(b);
                                        if (rankA !== rankB) {
                                            return rankA - rankB;
                                        }
                                        let qtyA = getLineQuantity(a);
                                        let qtyB = getLineQuantity(b);
                                        if (qtyA !== qtyB) {
                                            return qtyB - qtyA;
                                        }
                                        return a.localeCompare(b);
                                    });
                                    groupedProducts[family].forEach(line => { resultText += `- ${line}\n`; });
                                });
                            } else {
                                resultText += "- Ürün bulunamadı.\n";
                            }

                            if (progress) progress.remove();

                            if (resultText.trim()) {
                                sendToDesktopApp(resultText.trim()).then(success => {
                                    if (!success) {
                                        navigator.clipboard.writeText(resultText.trim()).then(() => {
                                            showToast(
                                                isFiltered ? "Seçilenler Dexter'a Aktarılıyor" : "Siparişler Dexter'a Aktarılıyor", 
                                                `${rows.length} Siparişten toplam ${sortedProducts.length} model kopyalandı ve uygulama açılıyor.`
                                            );
                                        }).catch(err => {
                                            console.error(err);
                                            showToast("Siparişler Dexter'a Aktarılıyor", `${rows.length} Siparişten toplam ${sortedProducts.length} model kopyalandı ve uygulama açılıyor.`);
                                        });
                                        launchDesktopApp(allProductLines.trim());
                                    }
                                    showScrapeSummaryModal(resultText.trim(), noteOrders, customOrders, refundOrders, products, orderNotesMap, allOrders.size, orderProductsMap);
                                });
                            } else {
                                showToast("Sipariş Bulunamadı", "Sipariş verilerinden ürün detayları çözümlenemedi.");
                            }
                        })
                        .catch(err => {
                            if (progress) progress.remove();
                            console.warn("[Dexter Extension] API fetch failed, falling back to DOM scraping: ", err);
                            runShopifyDOMScraperFallback();
                        });
                });
            }
        } catch (err) {
            console.error("[Dexter Extension] Error in runShopifyScrape:", err);
        }

        // Shopify DOM Scraper Fallback function (nested inside runShopifyScrape for scope clean isolation)
        function runShopifyDOMScraperFallback() {
            const rowSelectors = [
                'tr.Polaris-IndexTable__Row',
                '.Polaris-IndexTable__TableRow',
                '[class*="IndexTable__Row"]',
                '[class*="TableRow"]',
                'tr'
            ];

            let allRows = [];
            for (const sel of rowSelectors) {
                let found = [];
                function findRows(node) {
                    if (!node) return;
                    if (node.querySelectorAll) {
                        const res = node.querySelectorAll(sel);
                        if (res.length > 0) {
                            found = found.concat(Array.from(res));
                        }
                    }
                    if (node.children) {
                        for (const child of node.children) findRows(child);
                    }
                    if (node.shadowRoot) findRows(node.shadowRoot);
                }
                findRows(document.body);

                const valid = found.filter(row => {
                    const cells = row.querySelectorAll('td');
                    const isHeader = row.querySelector('th') || row.classList.contains('Polaris-IndexTable__TableRow--header') || row.closest('thead');
                    return !isHeader && cells.length >= 3;
                });
                if (valid.length > 0) {
                    allRows = valid;
                    break;
                }
            }

            if (allRows.length === 0) {
                showToast("Sipariş Bulunamadı", "Ekranınızda listelenen herhangi bir sipariş bulunamadı.");
                return;
            }

            let rows = Array.from(allRows).filter(row => {
                const checkbox = row.querySelector('input[type="checkbox"]');
                return row.classList.contains('Polaris-IndexTable__TableRow--selected') || 
                       row.classList.contains('Polaris-IndexTable__Row--selected') || 
                       (checkbox && checkbox.checked);
            });

            const isFiltered = rows.length > 0;
            if (!isFiltered) {
                rows = Array.from(allRows);
            }

            let itemsColIndex = -1;
            let orderColIndex = -1;
            
            let tableHeaders = [];
            function findHeaders(node) {
                if (!node) return;
                if (node.querySelectorAll) {
                    const res = node.querySelectorAll('th');
                    if (res.length > 0) tableHeaders = tableHeaders.concat(Array.from(res));
                }
                if (node.children) {
                    for (const child of node.children) findHeaders(child);
                }
                if (node.shadowRoot) findHeaders(node.shadowRoot);
            }
            findHeaders(document.body);

            tableHeaders.forEach((th, idx) => {
                const text = (th.innerText || '').toLowerCase();
                if (text.includes('ürün') || text.includes('item') || text.includes('product') || text.includes('satın alınan') || text.includes('alınanlar')) {
                    itemsColIndex = idx;
                }
                if (text.includes('sipariş') || text.includes('order') || text.includes('kod')) {
                    orderColIndex = idx;
                }
            });

            let products = {};
            let noteOrders = new Set();
            let customOrders = new Set();
            let refundOrders = new Set();
            let orderNotesMap = {};
            let orderProductsMap = {};
            let orderNoteProductsMap = {};
            let orderCustomProductsMap = {};
            let allOrders = new Set();
            let allProductLines = "";

            rows.forEach((row, rowIdx) => {
                const cells = row.querySelectorAll('td');
                if (cells.length < 3) return;

                let orderCode = "";
                if (orderColIndex !== -1 && cells.length > orderColIndex) {
                    orderCode = cells[orderColIndex].innerText.trim();
                }
                if (!orderCode) {
                    const rowText = row.innerText || '';
                    const m = rowText.match(/#\d+/);
                    orderCode = m ? m[0] : `Sipariş-${rowIdx + 1}`;
                }

                allOrders.add(orderCode);

                const rowTextLower = (row.innerText || '').toLowerCase();
                let orderIsRefund = rowTextLower.includes("iade") || rowTextLower.includes("refunded") || rowTextLower.includes("kısmi");
                if (orderIsRefund) refundOrders.add(orderCode);

                let itemsText = "";
                if (itemsColIndex !== -1 && cells.length > itemsColIndex) {
                    itemsText = cells[itemsColIndex].innerText;
                }

                if (!itemsText) {
                    cells.forEach(cell => {
                        const text = cell.innerText || '';
                        if (text.toLowerCase().includes('iphone') || text.toLowerCase().includes('kılıf') || text.toLowerCase().includes('case') || text.toLowerCase().includes('model')) {
                            itemsText = text;
                        }
                    });
                }

                if (!itemsText && cells.length >= 5) {
                    itemsText = cells[4].innerText;
                }

                if (!itemsText) return;

                let cardText = "";
                const parts = itemsText.split(/,|\\n/);
                parts.forEach(part => {
                    if (!part.trim()) return;

                    let title = part.trim();
                    let qty = 1;
                    let skuCode = "";

                    const qtyMatch = part.match(/(\d+)\s*x/i) || part.match(/x\s*(\d+)/i) || part.match(/(\d+)\s*adet/i);
                    if (qtyMatch) {
                        qty = parseInt(qtyMatch[1]) || 1;
                        title = title.replace(qtyMatch[0], '').trim();
                    }

                    const codeMatch = part.match(new RegExp('\\(([^)]+)\\)')) || part.match(new RegExp('-\\s*([A-Z0-9-]+)', 'i'));
                    if (codeMatch) {
                        skuCode = codeMatch[1].replace(/SKU|Kod/gi, '').replace(':', '').trim();
                    }

                    title = title.replace(new RegExp('\\([^)]+\\)', 'g'), '').replace(new RegExp('-\\s*[A-Z0-9-]+', 'gi'), '').trim();

                    const parsed = parseCodeAndModel(title, "");
                    if (parsed.code === "KOD-YOK" && skuCode && skuCode.toUpperCase() !== "KOD-YOK") {
                        parsed.code = skuCode;
                    }
                    
                    if (parsed.code !== "KOD-YOK") {
                        const escapedCode = parsed.code.replace(/[-\/\\^$*+?.()|[\\\]{}]/g, '\\$&');
                        parsed.productName = parsed.productName.replace(new RegExp(`\\(${escapedCode}\\)`, 'gi'), '');
                        parsed.productName = parsed.productName.replace(new RegExp(`\\b${escapedCode}\\b`, 'gi'), '');
                        parsed.productName = parsed.productName.replace(/\s+/g, ' ').trim();
                    }

                    const line = `- ${qty}x ${parsed.productName} (${parsed.code}) (${parsed.model})`;
                    cardText += line + "\n";
                    
                    let productCheck = checkSpecialConditions(parsed.productName + " " + parsed.model);
                    if (orderIsRefund) {
                        refundOrders.add(orderCode);
                    } else if (productCheck.isNote) {
                        noteOrders.add(orderCode);
                        if (!orderNoteProductsMap[orderCode]) {
                            orderNoteProductsMap[orderCode] = [];
                        }
                        orderNoteProductsMap[orderCode].push(line);
                    } else if (productCheck.isCustom) {
                        customOrders.add(orderCode);
                        if (!orderCustomProductsMap[orderCode]) {
                            orderCustomProductsMap[orderCode] = [];
                        }
                        orderCustomProductsMap[orderCode].push(line);
                    } else {
                        allProductLines += line + "\n";
                        const key = `${parsed.productName} (${parsed.code}) (${parsed.model})`;
                        products[key] = (products[key] || 0) + qty;
                    }
                });

                if (cardText.trim()) {
                    orderProductsMap[orderCode] = cardText.trim();
                }
            });

            let resultText = "### 📝 Müşteri Notları Olan Siparişler:\n";
            if (noteOrders.size > 0) {
                noteOrders.forEach(id => {
                    let noteText = orderNotesMap[id] || "Not belirtilmemiş";
                    let prodLines = orderNoteProductsMap[id] || [];
                    resultText += `- **Sipariş ${id}**:\n`;
                    prodLines.forEach(line => {
                        resultText += `  ${line}\n`;
                    });
                    resultText += `  > Not: ${noteText}\n`;
                });
            } else {
                resultText += "- Bulunamadı\n";
            }

            resultText += "\n### 🎨 Kişiye Özel Tasarımlar:\n";
            if (customOrders.size > 0) {
                customOrders.forEach(id => {
                    let prodLines = orderCustomProductsMap[id] || [];
                    resultText += `- **Sipariş ${id}**:\n`;
                    prodLines.forEach(line => {
                        resultText += `  ${line}\n`;
                    });
                });
            } else {
                resultText += "- Bulunamadı\n";
            }

            resultText += "\n### ↩️ İade Edilen Siparişler:\n";
            if (refundOrders.size > 0) {
                refundOrders.forEach(id => {
                    let prodLines = orderProductsMap[id] || "";
                    resultText += `- **Sipariş ${id}**:\n`;
                    if (prodLines.trim()) {
                        prodLines.split('\n').forEach(line => {
                            if (line.trim()) resultText += `  ${line}\n`;
                        });
                    }
                });
            } else {
                resultText += "- Bulunamadı\n";
            }

            resultText += "\n### 📦 Baskı Sırası (Modellere Göre):\n";
            let sortedProducts = Object.keys(products).sort((a, b) => products[b] - products[a]);
            if (sortedProducts.length > 0) {
                let groupedProducts = {};
                const familyOrder = [
                    "iPhone 17 Modelleri", "iPhone 16 Modelleri", "iPhone 15 Modelleri", "iPhone 14 Modelleri",
                    "iPhone 13 Modelleri", "iPhone 12 Modelleri", "iPhone 11 Modelleri", "iPhone XS Modelleri",
                    "iPhone X Modelleri", "iPhone 8 Modelleri", "iPhone 7 Modelleri", "iPhone 6 Modelleri", "Diğer Ürünler"
                ];
                
                function getFamily(key) {
                    if (key.includes("iPhone 17")) return "iPhone 17 Modelleri";
                    if (key.includes("iPhone 16")) return "iPhone 16 Modelleri";
                    if (key.includes("iPhone 15")) return "iPhone 15 Modelleri";
                    if (key.includes("iPhone 14")) return "iPhone 14 Modelleri";
                    if (key.includes("iPhone 13")) return "iPhone 13 Modelleri";
                    if (key.includes("iPhone 12")) return "iPhone 12 Modelleri";
                    if (key.includes("iPhone 11")) return "iPhone 11 Modelleri";
                    if (key.includes("iPhone XS")) return "iPhone XS Modelleri";
                    if (key.includes("iPhone X")) return "iPhone X Modelleri";
                    if (key.includes("iPhone 8")) return "iPhone 8 Modelleri";
                    if (key.includes("iPhone 7")) return "iPhone 7 Modelleri";
                    if (key.includes("iPhone 6")) return "iPhone 6 Modelleri";
                    return "Diğer Ürünler";
                }

                function getModelSuffixRank(line) {
                    let k = line.toLowerCase();
                    if (k.includes("pro max")) return 4;
                    if (k.includes("pro")) return 3;
                    if (k.includes("mini") || k.includes("plus") || k.includes("16e") || k.includes("air")) return 2;
                    return 1;
                }

                function getLineQuantity(line) {
                    let m = line.match(/^(\d+)x/);
                    return m ? parseInt(m[1]) || 0 : 0;
                }

                sortedProducts.forEach(key => {
                    let family = getFamily(key);
                    if (!groupedProducts[family]) groupedProducts[family] = [];
                    groupedProducts[family].push(`${products[key]}x ${key}`);
                });

                let familyTotals = {};
                for (const [family, lines] of Object.entries(groupedProducts)) {
                    let total = 0;
                    lines.forEach(line => {
                        total += getLineQuantity(line);
                    });
                    familyTotals[family] = total;
                }

                let familiesSorted = Object.keys(groupedProducts).sort((a, b) => {
                    let totalA = familyTotals[a] || 0;
                    let totalB = familyTotals[b] || 0;
                    if (totalA !== totalB) {
                        return totalB - totalA;
                    }
                    let indexA = familyOrder.indexOf(a);
                    let indexB = familyOrder.indexOf(b);
                    if (indexA === -1) indexA = 999;
                    if (indexB === -1) indexB = 999;
                    return indexA - indexB;
                });

                familiesSorted.forEach(family => {
                    resultText += `\n🔽 **${family} (Toplam: ${familyTotals[family]} Adet)**\n`;
                    groupedProducts[family].sort((a, b) => {
                        let rankA = getModelSuffixRank(a);
                        let rankB = getModelSuffixRank(b);
                        if (rankA !== rankB) {
                            return rankA - rankB;
                        }
                        let qtyA = getLineQuantity(a);
                        let qtyB = getLineQuantity(b);
                        if (qtyA !== qtyB) {
                            return qtyB - qtyA;
                        }
                        return a.localeCompare(b);
                    });
                    groupedProducts[family].forEach(line => { resultText += `- ${line}\n`; });
                });
            } else {
                resultText += "- Ürün bulunamadı.\n";
            }

            if (resultText.trim()) {
                sendToDesktopApp(resultText.trim()).then(success => {
                    if (!success) {
                        navigator.clipboard.writeText(resultText.trim()).then(() => {
                            showToast(
                                isFiltered ? "Seçilenler Dexter'a Aktarılıyor" : "Siparişler Dexter'a Aktarılıyor", 
                                `${rows.length} Siparişten toplam ${sortedProducts.length} model kopyalandı ve uygulama açılıyor.`
                            );
                        }).catch(err => {
                            console.error(err);
                            showToast("Siparişler Dexter'a Aktarılıyor", `${rows.length} Siparişten toplam ${sortedProducts.length} model kopyalandı ve uygulama açılıyor.`);
                        });
                        launchDesktopApp(allProductLines.trim());
                    }
                    showScrapeSummaryModal(resultText.trim(), noteOrders, customOrders, refundOrders, products, orderNotesMap, allOrders.size, orderProductsMap);
                });
            } else {
                showToast("Sipariş Bulunamadı", "Listeden ürün veya model bilgisi çekilemedi.");
            }
        }
    }

    // Listen for messages from the extension popup
    chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
        if (message.action === "trigger_scrape") {
            try {
                const url = window.location.href;
                if (url.includes('shopier.com')) {
                    runShopierScrape();
                    sendResponse({ success: true });
                } else if (url.includes('shopify.com')) {
                    runShopifyScrape();
                    sendResponse({ success: true });
                } else {
                    sendResponse({ error: "Desteklenmeyen web sitesi. Lütfen Shopify veya Shopier Siparişler sayfasını açın." });
                }
            } catch (err) {
                console.error("[Dexter Extension] Scrape error:", err);
                sendResponse({ error: err.message });
            }
        }
        return true;
    });

    function initFloatingScrapeButton() {
        setInterval(() => {
            const url = window.location.href;
            const isShopifyOrders = url.includes('shopify.com') && url.includes('/orders') && !url.match(/\/orders\/\d+(\/|$)/);
            const isShopier = url.includes('shopier.com');
            const shouldShow = isShopifyOrders || isShopier;

            const existingBtn = document.getElementById('dexter-floating-scrape-btn');

            if (!shouldShow) {
                if (existingBtn) {
                    existingBtn.remove();
                }
                return;
            }

            if (existingBtn) {
                return; // already injected
            }

            // Create floating button
            const btn = document.createElement('button');
            btn.id = 'dexter-floating-scrape-btn';
            btn.type = 'button';
            btn.innerHTML = `
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
                    <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/>
                    <polyline points="7 10 12 15 17 10"/>
                    <line x1="12" y1="15" x2="12" y2="3"/>
                </svg>
                Dexigner'a Aktar
            `;

            // Click handler
            btn.addEventListener('click', (e) => {
                e.preventDefault();
                e.stopPropagation();
                if (url.includes('shopier.com')) {
                    runShopierScrape();
                } else if (url.includes('shopify.com')) {
                    runShopifyScrape();
                }
            });

            document.body.appendChild(btn);
            console.log("[Dexter Extension] Injected floating action button successfully.");
        }, 1500);
    }

    async function init() {
        await loadRemoteConfig();
        await fetchLocalSettings();
        const url = window.location.href;
        if (url.includes('shopier.com')) {
            initShopier();
        } else if (url.includes('shopify.com')) {
            initShopify();
        }
        initFloatingScrapeButton();
    }
    init();
})();
