// popup.js - Dexter Sipariş Entegrasyonu Popup Script

const SUPABASE_URL = "https://pbvelftrjdswqfcjmfit.supabase.co";
const SUPABASE_ANON_KEY = "sb_publishable_vJxGKyMa489FJpvWaAwZgA_nsSizUQ0";

const viewLogin = document.getElementById('view-login');
const viewStatus = document.getElementById('view-status');
const txtEmail = document.getElementById('txt-email');
const txtPassword = document.getElementById('txt-password');
const btnLogin = document.getElementById('btn-login');
const btnLogout = document.getElementById('btn-logout');
const loginError = document.getElementById('login-error');
const lblEmail = document.getElementById('lbl-email');
const lblExpiry = document.getElementById('lbl-expiry');
const btnScrape = document.getElementById('btn-scrape');
const scrapeWarning = document.getElementById('scrape-warning');

// Initialize popup
document.addEventListener('DOMContentLoaded', () => {
    checkSession();
});

async function checkSession() {
    chrome.storage.local.get(['session'], async (result) => {
        if (result && result.session && result.session.loggedIn) {
            const session = result.session;
            // Check if expired
            if (session.expiresAt) {
                const expiryDate = new Date(session.expiresAt);
                if (expiryDate > new Date()) {
                    showStatusView(session);
                    return;
                }
            } else {
                showStatusView(session);
                return;
            }
        }
        
        // Fallback: check desktop app session
        try {
            const response = await fetch('http://127.0.0.1:4567/status');
            const data = await response.json();
            if (data && data.loggedIn) {
                const session = {
                    loggedIn: true,
                    email: data.email,
                    expiresAt: data.expiresAt || null,
                    userId: data.userId || null,
                    token: data.token || null
                };
                chrome.storage.local.set({ session }, () => {
                    showStatusView(session);
                });
                return;
            }
        } catch (err) {
            console.log("Desktop app status check failed:", err);
        }
        
        showLoginView();
    });
}

function showLoginView() {
    viewLogin.style.display = 'block';
    viewStatus.style.display = 'none';
    loginError.style.display = 'none';
    txtPassword.value = '';
}

function showStatusView(session) {
    viewLogin.style.display = 'none';
    viewStatus.style.display = 'block';
    lblEmail.textContent = session.email;
    
    if (session.expiresAt) {
        const expiryDate = new Date(session.expiresAt);
        const formattedDate = expiryDate.toLocaleDateString('tr-TR', {
            year: 'numeric',
            month: 'long',
            day: 'numeric'
        });
        const remainingDays = Math.ceil((expiryDate - new Date()) / (1000 * 60 * 60 * 24));
        if (remainingDays <= 0) {
            lblExpiry.textContent = `Lisans Süresi Doldu (${formattedDate})`;
            lblExpiry.style.color = 'var(--error)';
        } else {
            lblExpiry.textContent = `Lisans Süresi: ${formattedDate} (${remainingDays} gün kaldı)`;
            lblExpiry.style.color = 'var(--text-secondary)';
        }
    } else {
        lblExpiry.textContent = "Lisans Süresi: Süresiz / Sınırsız";
        lblExpiry.style.color = 'var(--text-secondary)';
    }
    
    // Check active tab's URL to enable or disable scraper trigger
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
        if (tabs && tabs[0]) {
            const url = tabs[0].url || "";
            if (url.includes('shopify.com') || url.includes('shopier.com')) {
                btnScrape.style.display = 'flex';
                btnScrape.disabled = false;
                scrapeWarning.style.display = 'none';
            } else {
                btnScrape.style.display = 'none';
                btnScrape.disabled = true;
                scrapeWarning.style.display = 'block';
            }
        }
    });
}

// Handle Login
btnLogin.addEventListener('click', async () => {
    const email = txtEmail.value.trim();
    const password = txtPassword.value;
    
    if (!email || !password) {
        showError("Lütfen tüm alanları doldurun.");
        return;
    }
    
    btnLogin.disabled = true;
    btnLogin.textContent = "Giriş yapılıyor...";
    loginError.style.display = 'none';
    
    try {
        // Step 1: Sign in with password
        const signinRes = await fetch(`${SUPABASE_URL}/auth/v1/token?grant_type=password`, {
            method: 'POST',
            headers: {
                'apikey': SUPABASE_ANON_KEY,
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ email, password })
        });
        
        if (!signinRes.ok) {
            const errData = await signinRes.json();
            throw new Error(errData.error_description || errData.error || "Giriş başarısız.");
        }
        
        const signinData = await signinRes.json();
        const userId = signinData.user.id;
        const token = signinData.access_token;
        
        // Step 2: Get user profile
        const profileRes = await fetch(`${SUPABASE_URL}/rest/v1/profiles?id=eq.${userId}`, {
            method: 'GET',
            headers: {
                'apikey': SUPABASE_ANON_KEY,
                'Authorization': `Bearer ${token}`,
                'Content-Type': 'application/json'
            }
        });
        
        if (!profileRes.ok) {
            throw new Error("Üyelik profili doğrulanamadı.");
        }
        
        const profiles = await profileRes.json();
        if (!profiles || profiles.length === 0) {
            throw new Error("Üyelik kaydı bulunamadı.");
        }
        
        const profile = profiles[0];
        
        // Step 3: Validate profile status
        if (!profile.is_active) {
            throw new Error("Hesabınız henüz yönetici tarafından onaylanmamıştır.");
        }
        
        if (profile.expires_at) {
            const expiryDate = new Date(profile.expires_at);
            if (expiryDate < new Date()) {
                throw new Error("Lisans süreniz dolmuştur. Yenilemek için lütfen yöneticiyle iletişime geçin.");
            }
        }
        
        // Save session
        const session = {
            loggedIn: true,
            email: profile.email || email,
            expiresAt: profile.expires_at || null,
            userId: userId,
            token: token
        };
        
        chrome.storage.local.set({ session }, () => {
            showStatusView(session);
        });
        
    } catch (err) {
        showError(err.message);
    } finally {
        btnLogin.disabled = false;
        btnLogin.textContent = "Giriş Yap";
    }
});

// Handle Logout
btnLogout.addEventListener('click', () => {
    chrome.storage.local.remove(['session'], () => {
        showLoginView();
    });
});

// Handle Scrape Action Trigger
btnScrape.addEventListener('click', () => {
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
        if (tabs && tabs[0]) {
            btnScrape.disabled = true;
            btnScrape.textContent = "Aktarım Başlatıldı...";
            
            chrome.tabs.sendMessage(tabs[0].id, { action: "trigger_scrape" }, (response) => {
                if (chrome.runtime.lastError) {
                    btnScrape.textContent = "Hata Oluştu ❌";
                    alert("Sayfa ile iletişim kurulamadı. Lütfen Shopify veya Shopier sayfasını yenileyin.");
                    btnScrape.disabled = false;
                    btnScrape.innerHTML = `<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round" style="margin-right: 4px;"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/></svg> Dexigner'a Aktar`;
                } else if (response && response.error) {
                    btnScrape.textContent = "Hata Oluştu ❌";
                    alert(response.error);
                    btnScrape.disabled = false;
                    btnScrape.innerHTML = `<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round" style="margin-right: 4px;"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/></svg> Dexigner'a Aktar`;
                } else {
                    btnScrape.textContent = "Aktarıldı! 🚀";
                    setTimeout(() => {
                        window.close();
                    }, 800);
                }
            });
        }
    });
});

function showError(msg) {
    loginError.textContent = msg;
    loginError.style.display = 'block';
}
